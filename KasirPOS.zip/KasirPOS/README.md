# Kasir POS (Android, offline)

Aplikasi kasir Android native (Kotlin + Jetpack Compose) dengan database lokal SQLite. Tidak butuh internet.

## Fitur
- Login kasir/admin (login awal: **admin / admin** — segera ganti password di Admin > User Kasir)
- Layar kasir: input barcode/PLU (mendukung scanner Bluetooth/USB & format `3*1001`), LIST PLU per menu, keranjang dengan qty +/-, Pending, Lap. Sales, Reprint, Kalkulator
- Pembayaran tunai: uang pas, nominal cepat, numpad, kembalian
- Cetak struk ke printer thermal Bluetooth (ESC/POS, 58 mm / 80 mm)
- Admin: kelola barang (PLU, nama, harga, menu), menu/kategori, user kasir, printer, info toko
- Struk: template bisa diedit sendiri (tag [L]/[C]/[R] + placeholder {BON}, {KASIR}, {ITEMS}, ...) dengan pratinjau langsung, format nomor bon, PPN, pemisah ribuan
- Nomor bon dan nama kasir tampil di layar kasir, layar bayar, dan struk
- Laporan penjualan: rekap barang terjual + detail per transaksi (bisa cetak ulang)
- Backup & restore semua data ke/dari file (.json)
- Tampilan otomatis landscape / portrait

## Build APK lewat GitHub
1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > workflow **Build APK** (jalan otomatis setiap push, atau klik *Run workflow*).
3. Setelah selesai, buka run tersebut dan unduh artifact **KasirPOS-apk** (isinya `app-debug.apk`).
4. Pindahkan APK ke HP dan install (izinkan "Install dari sumber tidak dikenal").

## Build lokal
Buka folder ini di Android Studio (Koala atau lebih baru) lalu Run, atau `gradle assembleDebug`.

## Printer Bluetooth
Pasangkan printer di Pengaturan Bluetooth HP > buka Admin > Printer > pilih perangkat > Tes Cetak.
