# Kasir POS (Android, offline)

Aplikasi kasir Android native (Kotlin + Jetpack Compose) dengan database lokal SQLite. Tidak butuh internet.

## Fitur
- Login kasir/admin (akun awal admin; segera ganti password di Pengaturan > User Kasir)
- Layar kasir: input barcode/PLU (mendukung scanner Bluetooth/USB & format `3*1001`), LIST PLU per menu, keranjang dengan qty +/-, Pending, Lap. Sales, Reprint, Kalkulator
- Pembayaran tunai: uang pas, nominal cepat, numpad, kembalian
- Cetak struk ke printer thermal Bluetooth (ESC/POS, 58 mm / 80 mm)
- Admin: kelola barang (PLU, nama, harga, menu), menu/kategori, user kasir, printer, info toko
- Struk: template bisa diedit sendiri (tag [L]/[C]/[R] + placeholder {BON}, {KASIR}, {ITEMS}, ...) dengan pratinjau langsung, format nomor bon, PPN, pemisah ribuan
- Nomor bon dan nama kasir tampil di layar kasir, layar bayar, dan struk
- Laporan penjualan: rekap barang terjual + detail per transaksi (bisa cetak ulang)
- Backup & restore semua data ke/dari file (.json)
- Level pengguna: Kasir, Staff, Admin
  - Kasir/Staff: laporan hanya barang terjual (tanpa rupiah) pada shift berjalan; Staff juga dapat mendaftarkan user Kasir dan mengatur printer
  - Hapus transaksi: wajib username+password minimal Staff dan catatan/alasan (hanya transaksi di shift yang belum ditutup)
  - Tutup Shift: input uang di laci, otorisasi minimal Staff, lalu hasil (disetor, seharusnya, selisih, daftar transaksi batal) + tombol print
  - Admin: semua fitur, laporan lengkap berisi rupiah, dan tab Shift (hasil + total semua tutup shift)
- Pembatalan butuh otorisasi: Batalkan Transaksi, hapus item/PLU yang sudah diinput (✕ dan −), dan hapus transaksi pending wajib username+password minimal Staff (tercatat di laporan)
- Tutup Shift tidak bisa dilakukan selama masih ada transaksi di keranjang atau pending
- Tombol **Report** di halaman login (Staff/Admin, tanpa perlu membuka kasir) dan tombol **Pengaturan** di halaman login (khusus Admin): hasil tutup shift per kasir, total uang harian + selisih per kasir, penjualan harian/mingguan/bulanan, transaksi batal/dihapus per kasir. Tiap report bisa dicetak (thermal) dan diunduh sebagai Excel (.xlsx)
- Tampilan otomatis landscape / portrait

## Build APK lewat GitHub
1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > workflow **Build APK** (jalan otomatis setiap push, atau klik *Run workflow*).
3. Setelah selesai, buka run tersebut dan unduh artifact **KasirPOS-apk** (isinya `app-debug.apk`).
4. Pindahkan APK ke HP dan install (izinkan "Install dari sumber tidak dikenal").

## Build lokal
Buka folder ini di Android Studio (Koala atau lebih baru) lalu Run, atau `gradle assembleDebug`.

## Printer Bluetooth
Pasangkan printer di Pengaturan Bluetooth HP > buka Admin > Printer > pilih perangkat > Tes Cetak.
