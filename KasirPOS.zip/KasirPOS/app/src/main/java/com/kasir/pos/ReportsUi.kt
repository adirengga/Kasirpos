package com.kasir.pos

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val REPORT_MENU = listOf(
    Triple(Rep.SHIFT, "Hasil Tutup Shift per Kasir", "Uang disetor, seharusnya, selisih tiap shift yang ditutup"),
    Triple(Rep.DAILY, "Total Uang Harian", "Jumlah semua kasir dalam 1 hari + selisih setoran per kasir"),
    Triple(Rep.SALES, "Total Penjualan", "Harian, mingguan, dan bulanan"),
    Triple(Rep.VOIDS, "Transaksi Batal / Dihapus", "Per kasir dalam 1 hari, lengkap dengan catatan"),
)

@Composable
fun ReportsScreen(onBack: () -> Unit) {
    val user = AppState.user
    var kind by remember { mutableStateOf<String?>(null) }
    BackHandler { if (kind != null) kind = null else onBack() }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(AppRed).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = { if (kind != null) kind = null else onBack() }) { Text("← Kembali", color = Color.White) }
            Text(
                REPORT_MENU.firstOrNull { it.first == kind }?.second ?: "Report",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f),
            )
        }
        if (user == null || user.rank() < 1) {
            Text("Report hanya dapat diakses Staff atau Admin.", Modifier.padding(16.dp), color = AppRed)
        } else if (kind == null) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                REPORT_MENU.forEach { (k, title, desc) ->
                    Card(
                        Modifier.fillMaxWidth().clickable { kind = k },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(desc, fontSize = 13.sp, color = Color.Gray)
                        }
                    }
                }
            }
        } else {
            ReportView(kind!!)
        }
    }
}

@Composable
private fun ReportView(kind: String) {
    val ctx = LocalContext.current
    val db = AppState.db
    var anchor by remember(kind) { mutableStateOf(System.currentTimeMillis()) }
    var mode by remember { mutableStateOf("day") } // khusus penjualan: day | week | month

    val table: RTable = remember(kind, anchor, mode, AppState.bon) {
        val (a, b) = Rep.dayRange(anchor)
        when (kind) {
            Rep.SHIFT -> Rep.shiftTable(anchor, db.shiftsBetween(a, b))
            Rep.DAILY -> Rep.dailyTable(anchor, db.shiftsBetween(a, b))
            Rep.SALES -> {
                val (f, t) = Rep.salesRange(mode, anchor)
                Rep.salesTable(mode, anchor, db.salesLite(f, t))
            }
            else -> Rep.voidTable(anchor, db.voidedSalesBetween(a, b), db.cartVoidsBetween(a, b))
        }
    }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    ) { uri ->
        if (uri != null) {
            val app = ctx.applicationContext
            val data = Xlsx.build(table)
            Thread {
                val msg = try {
                    val os = app.contentResolver.openOutputStream(uri, "wt") ?: throw Exception("tidak bisa menulis file")
                    os.use { it.write(data) }
                    "File Excel (.xlsx) tersimpan"
                } catch (e: Exception) {
                    "Gagal menyimpan: ${e.message}"
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post { toast(app, msg) }
            }.start()
        }
    }

    Column(Modifier.fillMaxSize().padding(10.dp)) {
        if (kind == Rep.SALES) {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("day" to "Harian", "week" to "Mingguan", "month" to "Bulanan").forEach { (m, l) ->
                    FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(l) })
                }
            }
        }
        // Navigasi periode
        val step: (Int) -> Unit = { n ->
            anchor = if (kind == Rep.SALES && mode == "month") Rep.addMonths(anchor, 12 * n)
            else if (kind == Rep.SALES) Rep.addMonths(anchor, n)
            else Rep.addDays(anchor, n)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { step(-1) }) { Text("◀") }
            Text(
                table.info.firstOrNull() ?: "", Modifier.weight(1f).padding(horizontal = 6.dp),
                textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            )
            OutlinedButton(onClick = { step(1) }) { Text("▶") }
        }
        TextButton(onClick = { anchor = System.currentTimeMillis() }) { Text("Hari ini") }

        // Tabel
        val widths = table.headers.indices.map { i ->
            val mx = (listOf(table.headers[i].length) +
                (table.rows + table.totals).map { table.cellText(it, i).length }).max()
            (mx * 8 + 20).coerceIn(64, 240).dp
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp)).verticalScroll(rememberScrollState()),
        ) {
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                TableRow(table, null, widths, header = true)
                if (table.rows.isEmpty()) Text("Tidak ada data", Modifier.padding(16.dp), color = Color.Gray)
                table.rows.forEachIndexed { i, r ->
                    TableRow(table, r, widths, header = false, shade = i % 2 == 1)
                }
                table.totals.forEach { TableRow(table, it, widths, header = false, bold = true) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { printTable(ctx, table) { toast(ctx, it) } },
                modifier = Modifier.weight(1f).height(52.dp),
            ) { Text("🖨 Cetak") }
            Button(
                onClick = { saver.launch(table.fileName + ".xlsx") },
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.weight(1f).height(52.dp),
            ) { Text("⬇ Unduh Excel") }
        }
    }
}

@Composable
private fun TableRow(
    t: RTable, row: List<Any>?, widths: List<androidx.compose.ui.unit.Dp>,
    header: Boolean, shade: Boolean = false, bold: Boolean = false,
) {
    val bg = when {
        header -> DarkRed
        bold -> Color(0xFFFFF3CD)
        shade -> Color(0xFFF5F5F5)
        else -> Color.White
    }
    Row(Modifier.background(bg).padding(vertical = 6.dp)) {
        t.headers.indices.forEach { i ->
            val txt = if (header) t.headers[i] else t.cellText(row!!, i)
            val right = i in t.moneyCols || (!header && row!!.getOrNull(i) is Int)
            Text(
                txt, Modifier.width(widths[i]).padding(horizontal = 8.dp),
                fontSize = 12.sp,
                fontWeight = if (header || bold) FontWeight.Bold else FontWeight.Normal,
                color = if (header) Color.White else if (i in t.moneyCols && (row!!.getOrNull(i) as? Long ?: 0L) < 0) AppRed else Color.Unspecified,
                textAlign = if (right) TextAlign.End else TextAlign.Start,
            )
        }
    }
}
