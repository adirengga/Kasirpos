package com.kasir.pos

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Baris member di layar kasir: label merah "Member" + kolom nomor HP. Enter = cari, nama member tampil otomatis. */
@Composable
fun MemberBar() {
    val ctx = LocalContext.current
    val db = AppState.db
    var phone by remember { mutableStateOf("") }
    val m = AppState.member

    fun search() {
        if (phone.isBlank()) return
        val f = db.memberByPhone(phone)
        if (f == null) {
            toast(ctx, "Nomor belum terdaftar. Gunakan menu Member")
        } else {
            AppState.member = f
            phone = ""
        }
    }

    Row(
        Modifier.fillMaxWidth().background(Color(0xFFDCE5EF)).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier.fillMaxWidth().height(36.dp).background(AppRed, RoundedCornerShape(8.dp)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Member", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 14.dp),
            )
            Box(
                Modifier.weight(1f).fillMaxHeight().padding(2.dp)
                    .background(Color.White, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (m == null) {
                    if (phone.isEmpty()) Text("Nomor Telepon atau Scan Kartu", fontSize = 13.sp, color = Color.Gray, maxLines = 1)
                    BasicTextField(
                        value = phone,
                        onValueChange = { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { search() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text(
                        "${m.name} · Poin ${rupiah(m.points)}", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (m != null) {
                Text(
                    "✕", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    modifier = Modifier.clickable { AppState.member = null }.padding(horizontal = 12.dp),
                )
            }
        }
    }
}

/**
 * Form daftar/ubah member. [edit] null = member baru. [admin] membuka kolom poin dan tombol hapus.
 * [onSaved] dipanggil dengan member yang tersimpan.
 */
@Composable
fun MemberFormDialog(edit: Member?, admin: Boolean, onClose: () -> Unit, onSaved: (Member) -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var phone by remember { mutableStateOf(edit?.phone ?: "") }
    var ttl by remember { mutableStateOf(edit?.ttl ?: "") }
    var addr by remember { mutableStateOf(edit?.address ?: "") }
    var pts by remember { mutableStateOf((edit?.points ?: 0L).toString()) }
    var confirmDel by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (edit == null) "Daftar Member" else "Ubah Member") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Field("Nama", name, { name = it })
                Field("Nomor HP", phone, { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) }, number = true)
                Field("TTL (tempat, tanggal lahir)", ttl, { ttl = it })
                Field("Alamat", addr, { addr = it }, minLines = 2)
                if (admin && edit != null) {
                    Field("Poin", pts, { pts = it.filter { c -> c.isDigit() }.take(9) }, number = true)
                    TextButton(onClick = { confirmDel = true }) { Text("Hapus member ini", color = AppRed) }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val err = db.saveMember(edit?.id ?: 0L, name, phone, ttl, addr)
                    if (err != null) {
                        toast(ctx, err)
                    } else {
                        val saved = db.memberByPhone(phone)
                        if (saved != null) {
                            if (admin && edit != null) db.setMemberPoints(saved.id, pts.toLongOrNull() ?: saved.points)
                            val fin = db.memberById(saved.id) ?: saved
                            if (AppState.member?.id == fin.id) AppState.member = fin
                            toast(ctx, "Member tersimpan")
                            onSaved(fin)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppRed),
            ) { Text("SIMPAN") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } },
    )
    if (confirmDel && edit != null) {
        AlertDialog(
            onDismissRequest = { confirmDel = false },
            title = { Text("Hapus member?") },
            text = { Text("${edit.name} (${edit.phone}) beserta ${rupiah(edit.points)} poinnya akan dihapus. Riwayat transaksi tetap ada.") },
            confirmButton = {
                Button(
                    onClick = {
                        db.deleteMember(edit.id)
                        if (AppState.member?.id == edit.id) AppState.member = null
                        confirmDel = false
                        onClose()
                        toast(ctx, "Member dihapus")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppRed),
                ) { Text("HAPUS") }
            },
            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Batal") } },
        )
    }
}

/** Pengaturan admin > Member: daftar, cari, ubah, hapus, dan poin per Rp 100. */
@Composable
fun MembersTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Member?>(null) }
    var adding by remember { mutableStateOf(false) }
    var per by remember { mutableStateOf(db.earnPer100().toString()) }
    val list = remember(tick, q) { db.members(q) }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = per, onValueChange = { per = it.filter { c -> c.isDigit() }.take(4) },
                label = { Text("Poin tiap Rp 100") }, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                db.setSetting("pt_per100", (per.toLongOrNull() ?: 1L).toString())
                per = db.earnPer100().toString()
                toast(ctx, "Pengaturan poin tersimpan")
            }) { Text("Simpan") }
        }
        Text(
            "Contoh: 1 = tiap belanja Rp 100 dapat 1 poin. Potong poin saat bayar: 100 poin = Rp 100.",
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Cari nama / nomor HP") }, modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { adding = true }) { Text("+ Member") }
        }
        Text("${list.size} member · ketuk untuk ubah/hapus", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { m ->
                Row(
                    Modifier.fillMaxWidth().clickable { edit = m }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.SemiBold)
                        Text("${m.phone}${if (m.address.isNotBlank()) " · " + m.address else ""}", fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("${rupiah(m.points)} poin", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
    if (adding) MemberFormDialog(null, true, { adding = false }) { adding = false; tick++ }
    edit?.let { m -> MemberFormDialog(m, true, { edit = null; tick++ }) { edit = null; tick++ } }
}
