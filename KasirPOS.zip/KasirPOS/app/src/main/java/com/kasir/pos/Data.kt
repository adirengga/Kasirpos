package com.kasir.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Category(val id: Long, val name: String)

data class Item(
    val id: Long,
    val plu: String,
    val name: String,
    val price: Long,
    val categoryId: Long,
    val categoryName: String,
)

data class User(val id: Long, val username: String, val name: String, val role: String)

data class CartLine(val item: Item, val qty: Int) {
    val total: Long get() = item.price * qty
}

data class SaleRow(
    val id: Long,
    val receipt: String,
    val time: Long,
    val cashier: String,
    val total: Long,
    val cash: Long,
    val change: Long,
)

data class SaleLine(val plu: String, val name: String, val price: Long, val qty: Int)

fun rupiah(v: Long): String = NumberFormat.getInstance(Locale("id", "ID")).format(v)

fun startOfDay(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfMonth(): Long = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1)
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun cv(vararg p: Pair<String, Any>) = ContentValues().apply {
    p.forEach { (k, v) ->
        when (v) {
            is Long -> put(k, v)
            is Int -> put(k, v)
            else -> put(k, v.toString())
        }
    }
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "kasir.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL COLLATE NOCASE, name TEXT NOT NULL, pass TEXT NOT NULL, role TEXT NOT NULL)")
        d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, plu TEXT UNIQUE NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL, category_id INTEGER NOT NULL DEFAULT 0)")
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt TEXT NOT NULL, time INTEGER NOT NULL, cashier TEXT NOT NULL, total INTEGER NOT NULL, cash INTEGER NOT NULL, change_amt INTEGER NOT NULL)")
        d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, plu TEXT, name TEXT, price INTEGER, qty INTEGER)")
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)")

        d.insert("users", null, cv("username" to "admin", "name" to "Administrator", "pass" to hash("admin"), "role" to "admin"))

        val defaults = mapOf(
            "store_name" to "TOKO SAYA",
            "store_addr" to "Alamat toko Anda",
            "store_phone" to "",
            "store_footer" to "Terima kasih atas kunjungan Anda",
            "printer_mac" to "",
            "printer_name" to "",
            "paper" to "32",
            "auto_print" to "1",
        )
        defaults.forEach { (k, v) -> d.insert("settings", null, cv("k" to k, "v" to v)) }

        val rokok = d.insert("categories", null, cv("name" to "Rokok"))
        val minum = d.insert("categories", null, cv("name" to "Minuman"))
        val makan = d.insert("categories", null, cv("name" to "Makanan"))
        d.insert("items", null, cv("plu" to "1001", "name" to "ROKOK CONTOH 16", "price" to 37600L, "category_id" to rokok))
        d.insert("items", null, cv("plu" to "1002", "name" to "AIR MINERAL 600ML", "price" to 3500L, "category_id" to minum))
        d.insert("items", null, cv("plu" to "1003", "name" to "MIE INSTAN GORENG", "price" to 3200L, "category_id" to makan))
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun hash(p: String): String =
        MessageDigest.getInstance("SHA-256").digest(p.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---------- Settings ----------
    fun getSetting(k: String, def: String = ""): String =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use {
            if (it.moveToFirst()) (it.getString(0) ?: def) else def
        }

    fun setSetting(k: String, v: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf(k, v))
    }

    // ---------- Users ----------
    fun login(u: String, p: String): User? =
        readableDatabase.rawQuery(
            "SELECT id,username,name,role FROM users WHERE username=? AND pass=?",
            arrayOf(u.trim(), hash(p)),
        ).use {
            if (it.moveToFirst()) User(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)) else null
        }

    fun users(): List<User> =
        readableDatabase.rawQuery("SELECT id,username,name,role FROM users ORDER BY role, name", null).use {
            val r = mutableListOf<User>()
            while (it.moveToNext()) r.add(User(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)))
            r
        }

    /** Mengembalikan pesan error, atau null jika berhasil. */
    fun saveUser(id: Long, username: String, name: String, pass: String, role: String): String? {
        if (username.isBlank() || name.isBlank()) return "Username dan nama wajib diisi"
        return try {
            if (id == 0L) {
                if (pass.length < 4) return "Password minimal 4 karakter"
                writableDatabase.insertOrThrow(
                    "users", null,
                    cv("username" to username.trim(), "name" to name.trim(), "pass" to hash(pass), "role" to role),
                )
            } else {
                val c = cv("name" to name.trim(), "role" to role)
                if (pass.isNotBlank()) {
                    if (pass.length < 4) return "Password minimal 4 karakter"
                    c.put("pass", hash(pass))
                }
                if (role != "admin" && isLastAdmin(id)) return "Harus ada minimal satu admin"
                writableDatabase.update("users", c, "id=?", arrayOf(id.toString()))
            }
            null
        } catch (e: Exception) {
            "Username sudah dipakai"
        }
    }

    private fun isLastAdmin(id: Long): Boolean {
        val isAdmin = readableDatabase.rawQuery("SELECT COUNT(*) FROM users WHERE id=? AND role='admin'", arrayOf(id.toString()))
            .use { it.moveToFirst(); it.getInt(0) > 0 }
        if (!isAdmin) return false
        val n = readableDatabase.rawQuery("SELECT COUNT(*) FROM users WHERE role='admin'", null)
            .use { it.moveToFirst(); it.getInt(0) }
        return n <= 1
    }

    fun deleteUser(id: Long): String? {
        if (isLastAdmin(id)) return "Admin terakhir tidak bisa dihapus"
        writableDatabase.delete("users", "id=?", arrayOf(id.toString()))
        return null
    }

    // ---------- Categories (Menu) ----------
    fun categories(): List<Category> =
        readableDatabase.rawQuery("SELECT id,name FROM categories ORDER BY name", null).use {
            val r = mutableListOf<Category>()
            while (it.moveToNext()) r.add(Category(it.getLong(0), it.getString(1)))
            r
        }

    fun saveCategory(id: Long, name: String) {
        if (id == 0L) writableDatabase.insert("categories", null, cv("name" to name.trim()))
        else writableDatabase.update("categories", cv("name" to name.trim()), "id=?", arrayOf(id.toString()))
    }

    fun deleteCategory(id: Long) {
        writableDatabase.execSQL("UPDATE items SET category_id=0 WHERE category_id=?", arrayOf(id))
        writableDatabase.delete("categories", "id=?", arrayOf(id.toString()))
    }

    // ---------- Items ----------
    private fun readItems(sql: String, args: Array<String>): List<Item> =
        readableDatabase.rawQuery(sql, args).use {
            val r = mutableListOf<Item>()
            while (it.moveToNext()) {
                r.add(Item(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getLong(4), it.getString(5)))
            }
            r
        }

    private val itemSelect =
        "SELECT i.id,i.plu,i.name,i.price,i.category_id,IFNULL(c.name,'-') FROM items i LEFT JOIN categories c ON c.id=i.category_id"

    fun items(q: String = "", cat: Long = -1): List<Item> {
        val where = StringBuilder("1=1")
        val args = mutableListOf<String>()
        if (q.isNotBlank()) {
            where.append(" AND (i.name LIKE ? OR i.plu LIKE ?)")
            args.add("%${q.trim()}%")
            args.add("%${q.trim()}%")
        }
        if (cat >= 0) {
            where.append(" AND i.category_id=?")
            args.add(cat.toString())
        }
        return readItems("$itemSelect WHERE $where ORDER BY i.name", args.toTypedArray())
    }

    fun itemByPlu(plu: String): Item? = readItems("$itemSelect WHERE i.plu=?", arrayOf(plu)).firstOrNull()

    /** false jika PLU sudah dipakai barang lain. */
    fun saveItem(id: Long, plu: String, name: String, price: Long, cat: Long): Boolean = runCatching {
        val c = cv("plu" to plu.trim(), "name" to name.trim(), "price" to price, "category_id" to cat)
        if (id == 0L) writableDatabase.insertOrThrow("items", null, c)
        else writableDatabase.update("items", c, "id=?", arrayOf(id.toString()))
    }.isSuccess

    fun deleteItem(id: Long) {
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
    }

    // ---------- Sales ----------
    fun saveSale(cashier: String, lines: List<SaleLine>, total: Long, cash: Long, change: Long): Long {
        val d = writableDatabase
        d.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            val n = d.rawQuery("SELECT COUNT(*) FROM sales WHERE time>=?", arrayOf(startOfDay().toString()))
                .use { it.moveToFirst(); it.getInt(0) } + 1
            val no = SimpleDateFormat("yyMMdd", Locale.US).format(Date(now)) + "%04d".format(n)
            val id = d.insertOrThrow(
                "sales", null,
                cv("receipt" to no, "time" to now, "cashier" to cashier, "total" to total, "cash" to cash, "change_amt" to change),
            )
            lines.forEach {
                d.insertOrThrow(
                    "sale_items", null,
                    cv("sale_id" to id, "plu" to it.plu, "name" to it.name, "price" to it.price, "qty" to it.qty),
                )
            }
            d.setTransactionSuccessful()
            return id
        } finally {
            d.endTransaction()
        }
    }

    private fun readSales(sql: String, args: Array<String>): List<SaleRow> =
        readableDatabase.rawQuery(sql, args).use {
            val r = mutableListOf<SaleRow>()
            while (it.moveToNext()) {
                r.add(SaleRow(it.getLong(0), it.getString(1), it.getLong(2), it.getString(3), it.getLong(4), it.getLong(5), it.getLong(6)))
            }
            r
        }

    fun sales(from: Long, cashier: String?, limit: Int): List<SaleRow> {
        val args = mutableListOf(from.toString())
        var where = "time>=?"
        if (cashier != null) {
            where += " AND cashier=?"
            args.add(cashier)
        }
        return readSales(
            "SELECT id,receipt,time,cashier,total,cash,change_amt FROM sales WHERE $where ORDER BY time DESC LIMIT $limit",
            args.toTypedArray(),
        )
    }

    fun sale(id: Long): SaleRow? =
        readSales("SELECT id,receipt,time,cashier,total,cash,change_amt FROM sales WHERE id=?", arrayOf(id.toString())).firstOrNull()

    fun saleLines(id: Long): List<SaleLine> =
        readableDatabase.rawQuery("SELECT plu,name,price,qty FROM sale_items WHERE sale_id=? ORDER BY id", arrayOf(id.toString())).use {
            val r = mutableListOf<SaleLine>()
            while (it.moveToNext()) r.add(SaleLine(it.getString(0), it.getString(1), it.getLong(2), it.getInt(3)))
            r
        }
}

/** State global aplikasi (tetap hidup saat layar diputar). */
object AppState {
    lateinit var db: Db
    var user by mutableStateOf<User?>(null)
    val cart = mutableStateListOf<CartLine>()
    val pending = mutableStateListOf<List<CartLine>>()
    var askBt: () -> Unit = {}

    fun init(ctx: Context) {
        if (!::db.isInitialized) db = Db(ctx.applicationContext)
    }

    fun add(item: Item, qty: Int = 1) {
        val i = cart.indexOfFirst { it.item.id == item.id }
        if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + qty) else cart.add(CartLine(item, qty))
    }

    fun change(i: Int, d: Int) {
        if (i !in cart.indices) return
        val l = cart[i]
        val q = l.qty + d
        if (q <= 0) cart.removeAt(i) else cart[i] = l.copy(qty = q)
    }
}
