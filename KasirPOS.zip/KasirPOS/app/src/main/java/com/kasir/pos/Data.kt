package com.kasir.pos

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Category(val id: Long, val name: String)

data class Item(
    val id: Long,
    val plu: String,
    val name: String,
    val price: Long,
    val categoryId: Long,
    val categoryName: String,
)

data class User(val id: Long, val username: String, val name: String, val role: String)

/** Level user: 0 = kasir, 1 = staff, 2 = admin. */
fun roleRank(role: String): Int = when (role) {
    "admin" -> 2
    "staff" -> 1
    else -> 0
}

fun User.rank(): Int = roleRank(role)

fun roleLabel(role: String): String = when (role) {
    "admin" -> "Admin"
    "staff" -> "Staff"
    else -> "Kasir"
}

data class CartLine(val item: Item, val qty: Int) {
    val total: Long get() = item.price * qty
}

data class SaleRow(
    val id: Long,
    val receipt: String,
    val time: Long,
    val cashier: String,
    val total: Long,
    val cash: Long,
    val change: Long,
    val status: Int = 0, // 0 = sah, 1 = dibatalkan
    val voidNote: String = "",
    val voidBy: String = "",
    val shiftId: Long = 0, // 0 = shift masih berjalan
    val userId: Long = 0,
    val voidTime: Long = 0,
)

data class SaleLine(val plu: String, val name: String, val price: Long, val qty: Int)

data class SoldRow(val plu: String, val name: String, val qty: Int, val total: Long)

data class ShiftRow(
    val id: Long,
    val userId: Long,
    val username: String,
    val name: String,
    val startTime: Long,
    val endTime: Long,
    val counted: Long, // uang fisik di laci
    val expected: Long, // seharusnya disetor sesuai data
    val diff: Long, // counted - expected
    val authBy: String,
    val txCount: Int,
    val voidCount: Int,
)

private const val SALE_COLS =
    "id,receipt,time,cashier,total,cash,change_amt,status,IFNULL(void_note,''),IFNULL(void_by,''),shift_id,user_id,void_time"

private const val SHIFTS_SQL =
    "CREATE TABLE shifts(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT 0, username TEXT, name TEXT, " +
        "start_time INTEGER NOT NULL DEFAULT 0, end_time INTEGER NOT NULL DEFAULT 0, counted INTEGER NOT NULL DEFAULT 0, " +
        "expected INTEGER NOT NULL DEFAULT 0, diff INTEGER NOT NULL DEFAULT 0, auth_by TEXT, " +
        "tx_count INTEGER NOT NULL DEFAULT 0, void_count INTEGER NOT NULL DEFAULT 0)"

/** Catatan pembatalan sebelum bayar: batal transaksi (cancel) atau hapus item (line). */
data class CartVoidRow(
    val id: Long,
    val time: Long,
    val userId: Long,
    val cashier: String,
    val kind: String, // "cancel" | "line"
    val detail: String,
    val amount: Long,
    val authBy: String,
    val note: String,
)

/** Data ringan satu transaksi sah untuk rekap penjualan. */
data class SalesLite(val time: Long, val total: Long, val qty: Int)

/** Satu kejadian batal/hapus pada sebuah shift (gabungan transaksi dihapus + batal sebelum bayar + hapus item). */
data class VoidEvent(val time: Long, val kind: String, val detail: String, val amount: Long, val note: String, val by: String)

private const val CART_VOIDS_SQL =
    "CREATE TABLE cart_voids(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, user_id INTEGER NOT NULL DEFAULT 0, " +
        "cashier TEXT, kind TEXT, detail TEXT, amount INTEGER NOT NULL DEFAULT 0, auth_by TEXT, note TEXT)"

const val DEFAULT_BON = "KSR-{YYMMDD}-{SEQ}"

/** Template struk bawaan (meniru struk contoh). Tag: [L] kiri, [C] tengah, [R] kanan. */
val DEFAULT_TEMPLATE = """
[C]{TOKO}
[C]{ALAMAT}
[C]{TELP}
{SEP}
[L]Bon  {BON}[R]Kasir : {KASIR}
{SEP}
{ITEMS}
{DASH}
[L]Total Item  {JML_ITEM}[R]{TOTAL}
[L]Tunai[R]{TUNAI}
[L]Kembalian[R]{KEMBALI}
[L]PPN ({PPN_PCT})[R]{PPN}
{SEP}
[L]Tgl. {TGL}
{DASH}
[C]{FOOTER}
""".trimIndent()

/** Pemisah ribuan untuk seluruh aplikasi (diatur di Admin > Struk). */
object Fmt {
    var sep: Char = ','
}

fun rupiah(v: Long): String {
    val s = kotlin.math.abs(v).toString()
    val sb = StringBuilder()
    s.forEachIndexed { i, c ->
        if (i > 0 && (s.length - i) % 3 == 0) sb.append(Fmt.sep)
        sb.append(c)
    }
    return (if (v < 0) "-" else "") + sb.toString()
}

fun startOfDay(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun startOfMonth(): Long = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1)
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun cv(vararg p: Pair<String, Any>) = ContentValues().apply {
    p.forEach { (k, v) ->
        when (v) {
            is Long -> put(k, v)
            is Int -> put(k, v)
            else -> put(k, v.toString())
        }
    }
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "kasir.db", null, 3) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL COLLATE NOCASE, name TEXT NOT NULL, pass TEXT NOT NULL, role TEXT NOT NULL)")
        d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, plu TEXT UNIQUE NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL, category_id INTEGER NOT NULL DEFAULT 0)")
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt TEXT NOT NULL, time INTEGER NOT NULL, cashier TEXT NOT NULL, total INTEGER NOT NULL, cash INTEGER NOT NULL, change_amt INTEGER NOT NULL, " +
                "user_id INTEGER NOT NULL DEFAULT 0, status INTEGER NOT NULL DEFAULT 0, void_note TEXT, void_by TEXT, " +
                "void_time INTEGER NOT NULL DEFAULT 0, shift_id INTEGER NOT NULL DEFAULT 0)")
        d.execSQL(SHIFTS_SQL)
        d.execSQL(CART_VOIDS_SQL)
        d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, plu TEXT, name TEXT, price INTEGER, qty INTEGER)")
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)")

        d.insert("users", null, cv("username" to "admin", "name" to "Administrator", "pass" to hash("admin"), "role" to "admin"))

        val defaults = mapOf(
            "store_name" to "TOKO SAYA",
            "store_addr" to "Alamat toko Anda",
            "store_phone" to "",
            "store_footer" to "Terima kasih atas kunjungan Anda",
            "printer_mac" to "",
            "printer_name" to "",
            "paper" to "32",
            "auto_print" to "1",
        )
        defaults.forEach { (k, v) -> d.insert("settings", null, cv("k" to k, "v" to v)) }

        val rokok = d.insert("categories", null, cv("name" to "Rokok"))
        val minum = d.insert("categories", null, cv("name" to "Minuman"))
        val makan = d.insert("categories", null, cv("name" to "Makanan"))
        d.insert("items", null, cv("plu" to "1001", "name" to "ROKOK CONTOH 16", "price" to 37600L, "category_id" to rokok))
        d.insert("items", null, cv("plu" to "1002", "name" to "AIR MINERAL 600ML", "price" to 3500L, "category_id" to minum))
        d.insert("items", null, cv("plu" to "1003", "name" to "MIE INSTAN GORENG", "price" to 3200L, "category_id" to makan))
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            d.execSQL("ALTER TABLE sales ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0")
            d.execSQL("ALTER TABLE sales ADD COLUMN status INTEGER NOT NULL DEFAULT 0")
            d.execSQL("ALTER TABLE sales ADD COLUMN void_note TEXT")
            d.execSQL("ALTER TABLE sales ADD COLUMN void_by TEXT")
            d.execSQL("ALTER TABLE sales ADD COLUMN void_time INTEGER NOT NULL DEFAULT 0")
            d.execSQL("ALTER TABLE sales ADD COLUMN shift_id INTEGER NOT NULL DEFAULT 0")
            d.execSQL(SHIFTS_SQL)
        }
        if (o < 3) {
            d.execSQL(CART_VOIDS_SQL)
        }
    }

    fun hash(p: String): String =
        MessageDigest.getInstance("SHA-256").digest(p.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---------- Settings ----------
    fun getSetting(k: String, def: String = ""): String =
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(k)).use {
            if (it.moveToFirst()) (it.getString(0) ?: def) else def
        }

    fun setSetting(k: String, v: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf(k, v))
    }

    // ---------- Users ----------
    fun login(u: String, p: String): User? =
        readableDatabase.rawQuery(
            "SELECT id,username,name,role FROM users WHERE username=? AND pass=?",
            arrayOf(u.trim(), hash(p)),
        ).use {
            if (it.moveToFirst()) User(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)) else null
        }

    /** Mengembalikan user jika username + password benar dan levelnya minimal staff; selain itu null. */
    fun authorize(username: String, pass: String): User? =
        login(username, pass)?.takeIf { it.rank() >= 1 }

    fun users(): List<User> =
        readableDatabase.rawQuery("SELECT id,username,name,role FROM users ORDER BY role, name", null).use {
            val r = mutableListOf<User>()
            while (it.moveToNext()) r.add(User(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)))
            r
        }

    /** Mengembalikan pesan error, atau null jika berhasil. */
    fun saveUser(id: Long, username: String, name: String, pass: String, role: String): String? {
        if (username.isBlank() || name.isBlank()) return "Username dan nama wajib diisi"
        return try {
            if (id == 0L) {
                if (pass.length < 4) return "Password minimal 4 karakter"
                writableDatabase.insertOrThrow(
                    "users", null,
                    cv("username" to username.trim(), "name" to name.trim(), "pass" to hash(pass), "role" to role),
                )
            } else {
                val c = cv("name" to name.trim(), "role" to role)
                if (pass.isNotBlank()) {
                    if (pass.length < 4) return "Password minimal 4 karakter"
                    c.put("pass", hash(pass))
                }
                if (role != "admin" && isLastAdmin(id)) return "Harus ada minimal satu admin"
                writableDatabase.update("users", c, "id=?", arrayOf(id.toString()))
            }
            null
        } catch (e: Exception) {
            "Username sudah dipakai"
        }
    }

    private fun isLastAdmin(id: Long): Boolean {
        val isAdmin = readableDatabase.rawQuery("SELECT COUNT(*) FROM users WHERE id=? AND role='admin'", arrayOf(id.toString()))
            .use { it.moveToFirst(); it.getInt(0) > 0 }
        if (!isAdmin) return false
        val n = readableDatabase.rawQuery("SELECT COUNT(*) FROM users WHERE role='admin'", null)
            .use { it.moveToFirst(); it.getInt(0) }
        return n <= 1
    }

    fun deleteUser(id: Long): String? {
        if (isLastAdmin(id)) return "Admin terakhir tidak bisa dihapus"
        writableDatabase.delete("users", "id=?", arrayOf(id.toString()))
        return null
    }

    // ---------- Categories (Menu) ----------
    fun categories(): List<Category> =
        readableDatabase.rawQuery("SELECT id,name FROM categories ORDER BY name", null).use {
            val r = mutableListOf<Category>()
            while (it.moveToNext()) r.add(Category(it.getLong(0), it.getString(1)))
            r
        }

    fun saveCategory(id: Long, name: String) {
        if (id == 0L) writableDatabase.insert("categories", null, cv("name" to name.trim()))
        else writableDatabase.update("categories", cv("name" to name.trim()), "id=?", arrayOf(id.toString()))
    }

    fun deleteCategory(id: Long) {
        writableDatabase.execSQL("UPDATE items SET category_id=0 WHERE category_id=?", arrayOf(id))
        writableDatabase.delete("categories", "id=?", arrayOf(id.toString()))
    }

    // ---------- Items ----------
    private fun readItems(sql: String, args: Array<String>): List<Item> =
        readableDatabase.rawQuery(sql, args).use {
            val r = mutableListOf<Item>()
            while (it.moveToNext()) {
                r.add(Item(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getLong(4), it.getString(5)))
            }
            r
        }

    private val itemSelect =
        "SELECT i.id,i.plu,i.name,i.price,i.category_id,IFNULL(c.name,'-') FROM items i LEFT JOIN categories c ON c.id=i.category_id"

    fun items(q: String = "", cat: Long = -1): List<Item> {
        val where = StringBuilder("1=1")
        val args = mutableListOf<String>()
        if (q.isNotBlank()) {
            where.append(" AND (i.name LIKE ? OR i.plu LIKE ?)")
            args.add("%${q.trim()}%")
            args.add("%${q.trim()}%")
        }
        if (cat >= 0) {
            where.append(" AND i.category_id=?")
            args.add(cat.toString())
        }
        return readItems("$itemSelect WHERE $where ORDER BY i.name", args.toTypedArray())
    }

    fun itemByPlu(plu: String): Item? = readItems("$itemSelect WHERE i.plu=?", arrayOf(plu)).firstOrNull()

    /** false jika PLU sudah dipakai barang lain. */
    fun saveItem(id: Long, plu: String, name: String, price: Long, cat: Long): Boolean = runCatching {
        val c = cv("plu" to plu.trim(), "name" to name.trim(), "price" to price, "category_id" to cat)
        if (id == 0L) writableDatabase.insertOrThrow("items", null, c)
        else writableDatabase.update("items", c, "id=?", arrayOf(id.toString()))
    }.isSuccess

    fun deleteItem(id: Long) {
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
    }

    // ---------- Sales ----------
    fun formatBon(f: String, now: Long, n: Int): String {
        val d = Date(now)
        fun df(p: String) = SimpleDateFormat(p, Locale.US).format(d)
        return f.replace("{YYMMDD}", df("yyMMdd")).replace("{YYYY}", df("yyyy")).replace("{YY}", df("yy"))
            .replace("{MM}", df("MM")).replace("{DD}", df("dd"))
            .replace("{SEQ6}", "%06d".format(n)).replace("{SEQ}", "%04d".format(n))
    }

    /** Nomor bon berikutnya (nomor urut direset setiap hari). */
    fun nextReceipt(now: Long = System.currentTimeMillis()): String {
        val n = readableDatabase.rawQuery("SELECT COUNT(*) FROM sales WHERE time>=?", arrayOf(startOfDay().toString()))
            .use { it.moveToFirst(); it.getInt(0) } + 1
        return formatBon(getSetting("bon_format", DEFAULT_BON).ifBlank { DEFAULT_BON }, now, n)
    }

    fun saveSale(cashier: String, lines: List<SaleLine>, total: Long, cash: Long, change: Long, userId: Long = 0L): Long {
        val d = writableDatabase
        d.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            val no = nextReceipt(now)
            val id = d.insertOrThrow(
                "sales", null,
                cv("receipt" to no, "time" to now, "cashier" to cashier, "total" to total, "cash" to cash, "change_amt" to change, "user_id" to userId),
            )
            lines.forEach {
                d.insertOrThrow(
                    "sale_items", null,
                    cv("sale_id" to id, "plu" to it.plu, "name" to it.name, "price" to it.price, "qty" to it.qty),
                )
            }
            d.setTransactionSuccessful()
            return id
        } finally {
            d.endTransaction()
        }
    }

    private fun readSales(sql: String, args: Array<String>): List<SaleRow> =
        readableDatabase.rawQuery(sql, args).use {
            val r = mutableListOf<SaleRow>()
            while (it.moveToNext()) {
                r.add(
                    SaleRow(
                        it.getLong(0), it.getString(1), it.getLong(2), it.getString(3), it.getLong(4), it.getLong(5), it.getLong(6),
                        it.getInt(7), it.getString(8) ?: "", it.getString(9) ?: "", it.getLong(10), it.getLong(11), it.getLong(12),
                    ),
                )
            }
            r
        }

    /** Filter transaksi milik user (transaksi lama tanpa user_id dicocokkan lewat nama kasir). */
    /** Nama kasir lain yang masih punya transaksi di shift belum ditutup, atau null. */
    fun openShiftOwner(u: User): String? =
        readableDatabase.rawQuery(
            "SELECT IFNULL(MAX(cashier),'') FROM sales WHERE shift_id=0 AND NOT ${mine()} GROUP BY user_id, cashier LIMIT 1",
            arrayOf(u.id.toString(), u.name),
        ).use { if (it.moveToFirst()) it.getString(0).ifBlank { "kasir lain" } else null }

    private fun mine(alias: String = "") =
        "(${alias}user_id=? OR (${alias}user_id=0 AND ${alias}cashier=?))"

    /** Semua transaksi (termasuk yang dibatalkan) sejak [from]. Khusus admin. */
    fun adminSales(from: Long, limit: Int): List<SaleRow> =
        readSales("SELECT $SALE_COLS FROM sales WHERE time>=? ORDER BY time DESC LIMIT $limit", arrayOf(from.toString()))

    /** Transaksi milik [u] sendiri (semua shift) sejak [from]. */
    fun mySales(u: User, from: Long, limit: Int): List<SaleRow> =
        readSales(
            "SELECT $SALE_COLS FROM sales WHERE time>=? AND ${mine()} ORDER BY time DESC LIMIT $limit",
            arrayOf(from.toString(), u.id.toString(), u.name),
        )

    /** Transaksi milik [u] pada shift yang sedang berjalan (belum ditutup). */
    fun shiftSales(u: User): List<SaleRow> =
        readSales(
            "SELECT $SALE_COLS FROM sales WHERE shift_id=0 AND ${mine()} ORDER BY time DESC",
            arrayOf(u.id.toString(), u.name),
        )

    fun sale(id: Long): SaleRow? =
        readSales("SELECT $SALE_COLS FROM sales WHERE id=?", arrayOf(id.toString())).firstOrNull()

    /** Membatalkan transaksi. Hanya bisa jika belum dibatalkan dan shift-nya belum ditutup. */
    fun voidSale(id: Long, by: String, note: String): String? {
        val c = ContentValues()
        c.put("status", 1)
        c.put("void_note", note.trim())
        c.put("void_by", by)
        c.put("void_time", System.currentTimeMillis())
        val n = writableDatabase.update("sales", c, "id=? AND status=0 AND shift_id=0", arrayOf(id.toString()))
        return if (n > 0) null else "Transaksi tidak bisa dibatalkan (sudah batal atau shift sudah ditutup)"
    }

    fun saleLines(id: Long): List<SaleLine> =
        readableDatabase.rawQuery("SELECT plu,name,price,qty FROM sale_items WHERE sale_id=? ORDER BY id", arrayOf(id.toString())).use {
            val r = mutableListOf<SaleLine>()
            while (it.moveToNext()) r.add(SaleLine(it.getString(0), it.getString(1), it.getLong(2), it.getInt(3)))
            r
        }

    /** Rekap barang terjual (tanpa transaksi batal). [u] null = semua (admin), selain itu shift berjalan milik [u]. */
    fun soldItems(from: Long, u: User?, openOnly: Boolean = true): List<SoldRow> {
        val args = mutableListOf<String>()
        var where = "s.status=0"
        if (u == null) {
            where += " AND s.time>=?"
            args.add(from.toString())
        } else {
            if (openOnly) {
                where += " AND s.shift_id=0 AND ${mine("s.")}"
            } else {
                where += " AND s.time>=? AND ${mine("s.")}"
                args.add(from.toString())
            }
            args.add(u.id.toString())
            args.add(u.name)
        }
        return readableDatabase.rawQuery(
            "SELECT si.plu, si.name, SUM(si.qty), SUM(si.price*si.qty) FROM sale_items si " +
                "JOIN sales s ON s.id=si.sale_id WHERE $where " +
                "GROUP BY si.plu, si.name ORDER BY SUM(si.qty) DESC, si.name",
            args.toTypedArray(),
        ).use {
            val r = mutableListOf<SoldRow>()
            while (it.moveToNext()) r.add(SoldRow(it.getString(0) ?: "", it.getString(1) ?: "", it.getInt(2), it.getLong(3)))
            r
        }
    }

    // ---------- Shift ----------
    private val shiftCols =
        "id,user_id,IFNULL(username,''),IFNULL(name,''),start_time,end_time,counted,expected,diff,IFNULL(auth_by,''),tx_count,void_count"

    private fun readShifts(sql: String, args: Array<String>): List<ShiftRow> =
        readableDatabase.rawQuery(sql, args).use {
            val r = mutableListOf<ShiftRow>()
            while (it.moveToNext()) {
                r.add(
                    ShiftRow(
                        it.getLong(0), it.getLong(1), it.getString(2), it.getString(3), it.getLong(4), it.getLong(5),
                        it.getLong(6), it.getLong(7), it.getLong(8), it.getString(9), it.getInt(10), it.getInt(11),
                    ),
                )
            }
            r
        }

    fun shifts(from: Long, limit: Int): List<ShiftRow> =
        readShifts("SELECT $shiftCols FROM shifts WHERE end_time>=? ORDER BY end_time DESC LIMIT $limit", arrayOf(from.toString()))

    /** Shift yang ditutup pada rentang [from, to), urut per kasir. */
    fun shiftsBetween(from: Long, to: Long): List<ShiftRow> =
        readShifts(
            "SELECT $shiftCols FROM shifts WHERE end_time>=? AND end_time<? ORDER BY name, end_time",
            arrayOf(from.toString(), to.toString()),
        )

    /** Transaksi (sudah dibayar) yang dihapus pada rentang waktu hapus [from, to). */
    fun voidedSalesBetween(from: Long, to: Long): List<SaleRow> =
        readSales(
            "SELECT $SALE_COLS FROM sales WHERE status=1 AND void_time>=? AND void_time<? ORDER BY void_time",
            arrayOf(from.toString(), to.toString()),
        )

    /** Transaksi sah (waktu, total, jumlah item) pada rentang [from, to) untuk rekap penjualan. */
    fun salesLite(from: Long, to: Long): List<SalesLite> =
        readableDatabase.rawQuery(
            "SELECT s.time, s.total, (SELECT IFNULL(SUM(qty),0) FROM sale_items WHERE sale_id=s.id) " +
                "FROM sales s WHERE s.status=0 AND s.time>=? AND s.time<? ORDER BY s.time",
            arrayOf(from.toString(), to.toString()),
        ).use {
            val r = mutableListOf<SalesLite>()
            while (it.moveToNext()) r.add(SalesLite(it.getLong(0), it.getLong(1), it.getInt(2)))
            r
        }

    // ---------- Pembatalan sebelum bayar ----------
    fun logCartVoid(u: User, kind: String, detail: String, amount: Long, authBy: String, note: String) {
        writableDatabase.insert(
            "cart_voids", null,
            cv(
                "time" to System.currentTimeMillis(), "user_id" to u.id, "cashier" to u.name, "kind" to kind,
                "detail" to detail, "amount" to amount, "auth_by" to authBy, "note" to note.trim(),
            ),
        )
    }

    fun cartVoidsBetween(from: Long, to: Long): List<CartVoidRow> =
        readableDatabase.rawQuery(
            "SELECT id,time,user_id,IFNULL(cashier,''),IFNULL(kind,''),IFNULL(detail,''),amount,IFNULL(auth_by,''),IFNULL(note,'') " +
                "FROM cart_voids WHERE time>=? AND time<? ORDER BY time",
            arrayOf(from.toString(), to.toString()),
        ).use {
            val r = mutableListOf<CartVoidRow>()
            while (it.moveToNext()) {
                r.add(
                    CartVoidRow(
                        it.getLong(0), it.getLong(1), it.getLong(2), it.getString(3), it.getString(4),
                        it.getString(5), it.getLong(6), it.getString(7), it.getString(8),
                    ),
                )
            }
            r
        }

    /** Semua kejadian batal/hapus milik kasir shift [s]: transaksi dihapus, batal transaksi, dan hapus item (sampai qty 0). */
    fun shiftEvents(s: ShiftRow): List<VoidEvent> {
        val out = mutableListOf<VoidEvent>()
        shiftVoids(s.id).forEach {
            out.add(VoidEvent(it.voidTime.takeIf { t -> t > 0 } ?: it.time, "Hapus transaksi", "Bon " + it.receipt, it.total, it.voidNote, it.voidBy))
        }
        val prev = readableDatabase.rawQuery(
            "SELECT IFNULL(MAX(end_time),0) FROM shifts WHERE user_id=? AND id<?",
            arrayOf(s.userId.toString(), s.id.toString()),
        ).use { it.moveToFirst(); it.getLong(0) }
        cartVoidsBetween(prev + 1, s.endTime + 1).filter { it.userId == s.userId }.forEach {
            val k = if (it.kind == "cancel") "Batal transaksi" else "Hapus item"
            out.add(VoidEvent(it.time, k, it.detail, it.amount, it.note, it.authBy))
        }
        return out.sortedBy { it.time }
    }

    fun shiftVoids(shiftId: Long): List<SaleRow> =
        readSales("SELECT $SALE_COLS FROM sales WHERE shift_id=? AND status=1 ORDER BY time", arrayOf(shiftId.toString()))

    /**
     * Menutup shift berjalan milik [u]. Uang yang seharusnya disetor = total transaksi sah (tidak batal).
     * Semua transaksi shift itu dikunci (tidak bisa dibatalkan lagi).
     */
    fun closeShift(u: User, counted: Long, authBy: String): ShiftRow {
        val d = writableDatabase
        d.beginTransaction()
        try {
            val args = arrayOf(u.id.toString(), u.name)
            var expected = 0L
            var tx = 0
            var voids = 0
            var first = 0L
            d.rawQuery(
                "SELECT IFNULL(SUM(CASE WHEN status=0 THEN total ELSE 0 END),0), " +
                    "IFNULL(SUM(CASE WHEN status=0 THEN 1 ELSE 0 END),0), " +
                    "IFNULL(SUM(CASE WHEN status=1 THEN 1 ELSE 0 END),0), IFNULL(MIN(time),0) " +
                    "FROM sales WHERE shift_id=0 AND ${mine()}",
                args,
            ).use {
                if (it.moveToFirst()) {
                    expected = it.getLong(0)
                    tx = it.getInt(1)
                    voids = it.getInt(2)
                    first = it.getLong(3)
                }
            }
            val last = d.rawQuery("SELECT IFNULL(MAX(end_time),0) FROM shifts WHERE user_id=?", arrayOf(u.id.toString()))
                .use { it.moveToFirst(); it.getLong(0) }
            val now = System.currentTimeMillis()
            voids += d.rawQuery(
                "SELECT COUNT(*) FROM cart_voids WHERE user_id=? AND time>? AND time<=?",
                arrayOf(u.id.toString(), last.toString(), now.toString()),
            ).use { it.moveToFirst(); it.getInt(0) }
            val start = if (first > 0) first else if (last > 0) last else now
            val id = d.insertOrThrow(
                "shifts", null,
                cv(
                    "user_id" to u.id, "username" to u.username, "name" to u.name,
                    "start_time" to start, "end_time" to now, "counted" to counted,
                    "expected" to expected, "diff" to (counted - expected), "auth_by" to authBy,
                    "tx_count" to tx, "void_count" to voids,
                ),
            )
            d.execSQL("UPDATE sales SET shift_id=? WHERE shift_id=0 AND ${mine()}", arrayOf<Any>(id, u.id, u.name))
            d.setTransactionSuccessful()
            return ShiftRow(id, u.id, u.username, u.name, start, now, counted, expected, counted - expected, authBy, tx, voids)
        } finally {
            d.endTransaction()
        }
    }

    // ---------- Backup / Restore ----------
    private val tables = listOf("users", "categories", "items", "sales", "sale_items", "settings", "shifts", "cart_voids")

    fun count(table: String): Int {
        if (table !in tables) return 0
        return readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null).use { it.moveToFirst(); it.getInt(0) }
    }

    private fun columns(t: String): Set<String> =
        readableDatabase.rawQuery("PRAGMA table_info($t)", null).use {
            val s = mutableSetOf<String>()
            while (it.moveToNext()) s.add(it.getString(1))
            s
        }

    fun exportJson(): String {
        val root = JSONObject()
        root.put("app", "KasirPOS")
        root.put("version", 3)
        root.put("created", System.currentTimeMillis())
        val data = JSONObject()
        for (t in tables) {
            val arr = JSONArray()
            readableDatabase.rawQuery("SELECT * FROM $t", null).use { c ->
                while (c.moveToNext()) {
                    val o = JSONObject()
                    for (i in 0 until c.columnCount) {
                        val n = c.getColumnName(i)
                        when (c.getType(i)) {
                            Cursor.FIELD_TYPE_NULL -> o.put(n, JSONObject.NULL)
                            Cursor.FIELD_TYPE_INTEGER -> o.put(n, c.getLong(i))
                            Cursor.FIELD_TYPE_FLOAT -> o.put(n, c.getDouble(i))
                            else -> o.put(n, c.getString(i))
                        }
                    }
                    arr.put(o)
                }
            }
            data.put(t, arr)
        }
        root.put("data", data)
        return root.toString()
    }

    /** Mengganti seluruh data dengan isi backup. Mengembalikan pesan error, atau null jika berhasil. */
    fun importJson(text: String): String? {
        val data: JSONObject
        try {
            val root = JSONObject(text)
            if (root.optString("app") != "KasirPOS") return "Bukan file backup Kasir POS"
            data = root.getJSONObject("data")
            // tabel shifts boleh tidak ada (backup dari versi lama)
            for (t in tables) if (t != "shifts" && t != "cart_voids") data.getJSONArray(t)
        } catch (e: Exception) {
            return "File backup tidak valid"
        }
        val users = data.getJSONArray("users")
        var hasAdmin = false
        for (i in 0 until users.length()) {
            if (users.getJSONObject(i).optString("role") == "admin") hasAdmin = true
        }
        if (!hasAdmin) return "Backup tidak berisi user admin"

        // Pengaturan printer milik perangkat ini tidak ikut diganti.
        val keepKeys = listOf("printer_mac", "printer_name")
        val keep = keepKeys.map { it to getSetting(it) }

        val d = writableDatabase
        d.beginTransaction()
        try {
            for (t in tables) d.delete(t, null, null)
            for (t in tables) {
                val cols = columns(t)
                val arr = data.optJSONArray(t) ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (t == "settings" && o.optString("k") in keepKeys) continue
                    val c = ContentValues()
                    val keys = o.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        if (k !in cols) continue
                        when (val v = o.get(k)) {
                            JSONObject.NULL -> c.putNull(k)
                            is Int -> c.put(k, v.toLong())
                            is Long -> c.put(k, v)
                            is Double -> c.put(k, v)
                            else -> c.put(k, v.toString())
                        }
                    }
                    d.insertOrThrow(t, null, c)
                }
            }
            keep.forEach { (k, v) ->
                d.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", arrayOf(k, v))
            }
            d.setTransactionSuccessful()
        } catch (e: Exception) {
            return "Restore gagal: ${e.message}"
        } finally {
            d.endTransaction()
        }
        return null
    }
}

/** State global aplikasi (tetap hidup saat layar diputar). */
object AppState {
    lateinit var db: Db
    var user by mutableStateOf<User?>(null)
    var tool by mutableStateOf<String?>(null) // "reports" | "admin": dibuka dari halaman login
    val cart = mutableStateListOf<CartLine>()
    val pending = mutableStateListOf<List<CartLine>>()
    var askBt: () -> Unit = {}

    /** Nomor bon yang akan dipakai untuk transaksi berikutnya. */
    var bon by mutableStateOf("")

    /** Kasir yang keluar (logout) tanpa tutup shift sambil membawa keranjang/pending. */
    var holdUser by mutableStateOf<User?>(null)

    /** Alasan [u] belum boleh membuka kasir, atau null jika boleh. */
    fun loginBlocker(u: User): String? {
        val h = holdUser
        if (cart.isEmpty() && pending.isEmpty()) holdUser = null
        else if (h != null && h.id != u.id) return h.name
        return db.openShiftOwner(u)
    }

    fun logoutKeepCart() {
        holdUser = if (cart.isNotEmpty() || pending.isNotEmpty()) user else null
        user = null
    }

    fun refreshBon() {
        bon = db.nextReceipt()
    }

    fun reloadFormat() {
        Fmt.sep = if (db.getSetting("thousand_sep", ",") == ".") '.' else ','
    }

    fun init(ctx: Context) {
        if (!::db.isInitialized) {
            db = Db(ctx.applicationContext)
            reloadFormat()
            restoreHeld()
        }
    }

    /** Keranjang + pending + pemiliknya sebagai JSON, supaya tidak hilang walau aplikasi ditutup. */
    fun heldJson(): String {
        val o = JSONObject()
        val owner = user ?: holdUser
        if (owner != null && (cart.isNotEmpty() || pending.isNotEmpty())) {
            o.put("uid", owner.id); o.put("uname", owner.username); o.put("name", owner.name); o.put("role", owner.role)
            fun arr(l: List<CartLine>) = JSONArray().also { a ->
                l.forEach { a.put(JSONObject().put("plu", it.item.plu).put("qty", it.qty)) }
            }
            o.put("cart", arr(cart.toList()))
            val p = JSONArray()
            pending.toList().forEach { p.put(arr(it)) }
            o.put("pending", p)
        }
        return o.toString()
    }

    private fun restoreHeld() {
        try {
            val o = JSONObject(db.getSetting("held_state", "{}"))
            if (!o.has("uid")) return
            fun lines(a: JSONArray): List<CartLine> {
                val r = mutableListOf<CartLine>()
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    db.itemByPlu(j.getString("plu"))?.let { r.add(CartLine(it, j.getInt("qty"))) }
                }
                return r
            }
            cart.addAll(lines(o.getJSONArray("cart")))
            val p = o.getJSONArray("pending")
            for (i in 0 until p.length()) {
                val l = lines(p.getJSONArray(i))
                if (l.isNotEmpty()) pending.add(l)
            }
            if (cart.isNotEmpty() || pending.isNotEmpty()) {
                holdUser = User(o.getLong("uid"), o.getString("uname"), o.getString("name"), o.getString("role"))
            }
        } catch (e: Exception) {
            // data tersimpan rusak: abaikan
        }
    }

    fun add(item: Item, qty: Int = 1) {
        val i = cart.indexOfFirst { it.item.id == item.id }
        if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + qty) else cart.add(CartLine(item, qty))
    }

    fun change(i: Int, d: Int) {
        if (i !in cart.indices) return
        val l = cart[i]
        val q = l.qty + d
        if (q <= 0) cart.removeAt(i) else cart[i] = l.copy(qty = q)
    }
}
