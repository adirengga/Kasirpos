package com.kasir.pos

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun PosScreen(onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val user = AppState.user ?: return
    var screen by remember { mutableStateOf("pos") }
    var dialog by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var pluQuery by remember { mutableStateOf("") }
    var removeReq by remember { mutableStateOf<Pair<Int, Int>?>(null) } // (indeks baris, perubahan qty)
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    LaunchedEffect(screen) { AppState.refreshBon() }

    if (screen == "admin") {
        BackHandler { screen = "pos" }
        AdminScreen(onBack = { screen = "pos" })
        return
    }
    if (screen == "pay") {
        PayScreen(onBack = { screen = "pos" }, onDone = { screen = "pos" })
        return
    }

    val cart = AppState.cart
    val total = cart.sumOf { it.total }
    val qtyAll = cart.sumOf { it.qty }
    val timeFmt = remember { SimpleDateFormat("dd/MM/yy HH:mm:ss", Locale.getDefault()) }

    fun submit() {
        val t = input.trim()
        if (t.isEmpty()) return
        var qty = 1
        var code = t
        Regex("^(\\d+)\\*(.+)$").find(t)?.let {
            qty = it.groupValues[1].toInt().coerceIn(1, 9999)
            code = it.groupValues[2].trim()
        }
        val exact = db.itemByPlu(code)
        if (exact != null) {
            AppState.add(exact, qty)
            input = ""
            return
        }
        val found = db.items(code)
        if (found.size == 1) {
            AppState.add(found[0], qty)
            input = ""
        } else {
            if (found.isEmpty()) toast(ctx, "Barang tidak ditemukan")
            pluQuery = code
            dialog = "plu"
            input = ""
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        TopBar(db.getSetting("store_name", "TOKO"), user, timeFmt.format(Date(now)), AppState.bon)
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val land = maxWidth > maxHeight
            if (land) {
                Row(Modifier.fillMaxSize()) {
                    LeftPane(
                        Modifier.weight(1f).fillMaxHeight(), input, { input = it }, { submit() },
                        { pluQuery = ""; dialog = "plu" }, { dialog = it },
                        { i, d -> removeReq = i to d },
                    )
                    TotalPanel(Modifier.width(300.dp).fillMaxHeight(), total, qtyAll, false) { screen = "pay" }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    LeftPane(
                        Modifier.weight(1f).fillMaxWidth(), input, { input = it }, { submit() },
                        { pluQuery = ""; dialog = "plu" }, { dialog = it },
                        { i, d -> removeReq = i to d },
                    )
                    TotalPanel(Modifier.fillMaxWidth(), total, qtyAll, true) { screen = "pay" }
                }
            }
        }
    }

    when (dialog) {
        "plu" -> PluDialog(pluQuery) { dialog = "" }
        "pending" -> PendingDialog { dialog = "" }
        "report" -> ReportDialog(user) { dialog = "" }
        "reprint" -> ReprintDialog(user) { dialog = "" }
        "calc" -> CalcDialog { dialog = "" }
        "void" -> VoidDialog(user) { dialog = "" }
        "cancel" -> AuthDialog(
            title = "Batalkan Transaksi",
            description = "Seluruh isi keranjang akan dihapus. Pembatalan transaksi butuh otorisasi dan alasan.",
            user = user, noteLabel = "Catatan / alasan (wajib)", noteRequired = true, confirmText = "BATALKAN",
            onClose = { dialog = "" },
            onAuthorized = { a, note ->
                if (AppState.cart.isNotEmpty()) {
                    db.logCartVoid(
                        user, "cancel", AppState.cart.joinToString("; ") { "${it.qty}x ${it.item.name}" },
                        AppState.cart.sumOf { it.total }, authLabel(a), note,
                    )
                    AppState.cart.clear()
                    toast(ctx, "Transaksi dibatalkan")
                }
                dialog = ""
            },
        )
        "shift" -> ShiftDialog(user, onFinish = { dialog = ""; onLogout() }) { dialog = "" }
        "more" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Tutup") } },
            title = { Text("Menu Lainnya") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (user.rank() >= 1) {
                        Button(onClick = { dialog = ""; screen = "admin" }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (user.rank() >= 2) "⚙ Pengaturan Admin" else "⚙ Pengaturan (User & Printer)")
                        }
                    }
                    OutlinedButton(onClick = { dialog = "void" }, modifier = Modifier.fillMaxWidth()) {
                        Text("🗑 Hapus Transaksi")
                    }
                    Button(
                        onClick = { dialog = "shift" },
                        colors = ButtonDefaults.buttonColors(containerColor = Olive),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("🔒 Tutup Shift") }
                    OutlinedButton(
                        onClick = { dialog = "cancel" },
                        enabled = AppState.cart.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Batalkan Transaksi") }
                    OutlinedButton(onClick = { dialog = ""; onLogout() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Keluar (Logout)")
                    }
                }
            },
        )
    }

    val rr = removeReq
    val rl = if (rr != null) AppState.cart.getOrNull(rr.first) else null
    if (rr != null && rl != null) {
        AuthDialog(
            title = "Hapus Item",
            description = "${rl.item.name} (${rl.item.plu}) akan dikurangi ${-rr.second}. Menghapus item yang sudah diinput butuh otorisasi.",
            user = user, noteLabel = "Catatan (opsional)", noteRequired = false, confirmText = "HAPUS",
            onClose = { removeReq = null },
            onAuthorized = { a, note ->
                val qty = minOf(-rr.second, rl.qty)
                db.logCartVoid(user, "line", "${qty}x ${rl.item.name} (${rl.item.plu})", rl.item.price * qty, authLabel(a), note)
                AppState.change(rr.first, rr.second)
                removeReq = null
            },
        )
    }
}

@Composable
private fun TopBar(store: String, user: User, time: String, bon: String) {
    Column(Modifier.fillMaxWidth().background(Color(0xFFDCE5EF)).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "🏪 $store", fontWeight = FontWeight.Bold, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            Text("🕒 $time", fontSize = 13.sp, maxLines = 1)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "🧾 Bon: $bon", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            Text("👤 ${roleLabel(user.role)}: ${user.name}", fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QtyBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(28.dp).background(Color(0xFFDCE5EF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
private fun LeftPane(
    modifier: Modifier,
    input: String,
    onInput: (String) -> Unit,
    onSubmit: () -> Unit,
    onList: () -> Unit,
    onAction: (String) -> Unit,
    onRemove: (Int, Int) -> Unit,
) {
    val cart = AppState.cart
    Column(modifier.padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = onInput,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Ketik atau scan barcode / PLU di sini", fontSize = 13.sp) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onSubmit() }),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                ),
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onList,
                colors = ButtonDefaults.buttonColors(containerColor = AppRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(56.dp),
            ) { Text("☰ LIST PLU", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(8.dp))

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wide = maxWidth > 460.dp
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFFC9D6E6)).padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Spacer(Modifier.width(36.dp))
                    Text("No", Modifier.width(28.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("PLU / Nama Barang", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (wide) Text("Harga(Rp)", Modifier.width(80.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text("QTY", Modifier.width(100.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("Total", Modifier.width(80.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                }
                if (cart.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().background(Color.White), contentAlignment = Alignment.Center) {
                        Text(
                            "Keranjang kosong\nScan barcode atau tekan LIST PLU",
                            textAlign = TextAlign.Center, color = Color.Gray,
                        )
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        itemsIndexed(cart.toList()) { i, l ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (i % 2 == 0) Color.White else Color(0xFFF5F8FC))
                                    .padding(vertical = 4.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.width(36.dp).clickable { onRemove(i, -l.qty) },
                                    contentAlignment = Alignment.Center,
                                ) { Text("✕", color = AppRed, fontWeight = FontWeight.Bold) }
                                Text("${i + 1}", Modifier.width(28.dp), fontSize = 12.sp)
                                Column(Modifier.weight(1f)) {
                                    Text(l.item.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2)
                                    Text(
                                        l.item.plu + if (!wide) " · Rp ${rupiah(l.item.price)}" else "",
                                        fontSize = 11.sp, color = Color.Gray,
                                    )
                                }
                                if (wide) Text(rupiah(l.item.price), Modifier.width(80.dp), fontSize = 13.sp, textAlign = TextAlign.End)
                                Row(
                                    Modifier.width(100.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                ) {
                                    QtyBtn("−") { onRemove(i, -1) }
                                    Text(
                                        "${l.qty}", Modifier.widthIn(min = 28.dp),
                                        textAlign = TextAlign.Center, fontWeight = FontWeight.Bold,
                                    )
                                    QtyBtn("+") { AppState.change(i, 1) }
                                }
                                Text(
                                    rupiah(l.total), Modifier.width(80.dp), fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End,
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        val actions = buildList {
            add(Triple("⏳", "Pending", "pending"))
            add(Triple("📊", "Lap. Sales", "report"))
            add(Triple("🖨", "Reprint", "reprint"))
            add(Triple("🧮", "Kalkulator", "calc"))
            add(Triple("⋯", "Lainnya", "more"))
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFFDCE5EF), RoundedCornerShape(8.dp)).padding(vertical = 4.dp)) {
            actions.forEach { (icon, label, key) ->
                Column(
                    Modifier.weight(1f).clickable { onAction(key) }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(icon, fontSize = 20.sp)
                    val shown = if (key == "pending" && AppState.pending.isNotEmpty()) "Pending (${AppState.pending.size})" else label
                    Text(shown, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun TotalPanel(modifier: Modifier, total: Long, qty: Int, compact: Boolean, onPay: () -> Unit) {
    Column(modifier.background(Brush.verticalGradient(listOf(AppRed, DarkRed))).padding(16.dp)) {
        if (compact) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Total RP", color = Color.White, fontSize = 13.sp)
                    Text(rupiah(total), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("$qty item", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                }
                Button(
                    onClick = onPay,
                    enabled = total > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppRed),
                    modifier = Modifier.height(60.dp),
                ) { Text("PILIH\nPEMBAYARAN →", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
            }
        } else {
            Text("Total RP", color = Color.White, fontSize = 16.sp)
            Text(
                rupiah(total), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.weight(1f))
            Divider(color = Color(0x88FFFFFF))
            Spacer(Modifier.height(6.dp))
            Row {
                Text("Total $qty Item", color = Color.White, modifier = Modifier.weight(1f))
                Text("$qty", color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onPay,
                enabled = total > 0,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppRed),
                modifier = Modifier.fillMaxWidth().height(72.dp),
            ) { Text("PILIH PEMBAYARAN →", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }
}

// ---------------------------------------------------------------- Dialogs

@Composable
private fun PluDialog(initial: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var q by remember { mutableStateOf(initial) }
    var cat by remember { mutableStateOf(-1L) }
    val cats = remember { db.categories() }
    val list = remember(q, cat) { db.items(q, cat) }
    FullDialog("List PLU", onClose) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            label = { Text("Cari nama / PLU") }, modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
            FilterChip(selected = cat == -1L, onClick = { cat = -1L }, label = { Text("Semua") })
            cats.forEach { c ->
                Spacer(Modifier.width(6.dp))
                FilterChip(selected = cat == c.id, onClick = { cat = c.id }, label = { Text(c.name) })
            }
        }
        if (list.isEmpty()) {
            Text("Tidak ada barang", color = Color.Gray, modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(list) { barang ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { AppState.add(barang, 1); toast(ctx, "+ ${barang.name}") }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(barang.name, fontWeight = FontWeight.SemiBold)
                        Text("${barang.plu} · ${barang.categoryName}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(barang.price)}", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
}

@Composable
private fun PendingDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val user = AppState.user ?: return
    var delIdx by remember { mutableStateOf(-1) }
    FullDialog("Transaksi Pending", onClose) {
        Button(
            onClick = {
                if (AppState.cart.isNotEmpty()) {
                    AppState.pending.add(AppState.cart.toList())
                    AppState.cart.clear()
                    toast(ctx, "Transaksi ditahan")
                }
            },
            enabled = AppState.cart.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Tahan transaksi saat ini") }
        Spacer(Modifier.height(8.dp))
        if (AppState.pending.isEmpty()) Text("Tidak ada transaksi pending", color = Color.Gray)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(AppState.pending.toList()) { i, p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "#${i + 1} · ${p.sumOf { it.qty }} item · Rp ${rupiah(p.sumOf { it.total })}",
                        Modifier.weight(1f),
                    )
                    TextButton(onClick = {
                        if (AppState.cart.isNotEmpty()) {
                            toast(ctx, "Tahan atau selesaikan transaksi saat ini dulu")
                        } else {
                            AppState.cart.addAll(p)
                            AppState.pending.removeAt(i)
                            onClose()
                        }
                    }) { Text("Panggil") }
                    TextButton(onClick = { delIdx = i }) { Text("Hapus", color = AppRed) }
                }
                Divider()
            }
        }
    }
    val del = AppState.pending.getOrNull(delIdx)
    if (del != null) {
        AuthDialog(
            title = "Hapus Transaksi Pending",
            description = "Transaksi pending #${delIdx + 1} (${del.sumOf { it.qty }} item) akan dihapus. Butuh otorisasi dan alasan.",
            user = user, noteLabel = "Catatan / alasan (wajib)", noteRequired = true, confirmText = "HAPUS",
            onClose = { delIdx = -1 },
            onAuthorized = { a, note ->
                db.logCartVoid(
                    user, "cancel", "(pending) " + del.joinToString("; ") { "${it.qty}x ${it.item.name}" },
                    del.sumOf { it.total }, authLabel(a), note,
                )
                AppState.pending.removeAt(delIdx)
                delIdx = -1
            },
        )
    }
}

@Composable
private fun ReportDialog(user: User, onClose: () -> Unit) {
    if (user.rank() >= 2) AdminReportDialog(onClose) else ShiftItemsDialog(user, onClose)
}

/** Kasir & staff: hanya barang yang sudah terjual pada shift berjalan, tanpa nominal rupiah. */
@Composable
private fun ShiftItemsDialog(user: User, onClose: () -> Unit) {
    val db = AppState.db
    val sold = remember { db.soldItems(0, user) }
    val trx = remember { db.shiftSales(user).count { it.status == 0 } }
    FullDialog("Barang Terjual (Shift Ini)", onClose) {
        Text("$trx transaksi · ${sold.sumOf { it.qty }} item", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Total rupiah hanya dapat dilihat admin. Hasil lengkap tampil saat Tutup Shift.",
            fontSize = 12.sp, color = Color.Gray,
        )
        Spacer(Modifier.height(8.dp))
        if (sold.isEmpty()) Text("Belum ada barang terjual", color = Color.Gray, modifier = Modifier.padding(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(sold) { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontWeight = FontWeight.SemiBold)
                        Text(r.plu, fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("${r.qty} pcs", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
}

/** Admin: semua transaksi semua kasir, lengkap dengan rupiah. Transaksi batal ditandai dan tidak dihitung. */
@Composable
private fun AdminReportDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var mode by remember { mutableStateOf(0) }
    var view by remember { mutableStateOf(0) }
    val open = remember { mutableStateListOf<Long>() }
    val from = when (mode) {
        0 -> startOfDay()
        1 -> startOfMonth()
        else -> 0L
    }
    val list = remember(mode) { db.adminSales(from, 2000) }
    val valid = list.filter { it.status == 0 }
    val sold = remember(mode) { db.soldItems(from, null) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    FullDialog("Laporan Penjualan", onClose) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("Hari ini") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Bulan ini") })
            FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("Semua") })
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "${valid.size} transaksi · ${sold.sumOf { it.qty }} item terjual · ${list.size - valid.size} batal",
            fontSize = 14.sp,
        )
        Text("Total Rp ${rupiah(valid.sumOf { it.total })}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = view == 0, onClick = { view = 0 }, label = { Text("Barang Terjual") })
            FilterChip(selected = view == 1, onClick = { view = 1 }, label = { Text("Per Transaksi") })
        }
        Spacer(Modifier.height(4.dp))
        if (list.isEmpty()) Text("Belum ada penjualan", color = Color.Gray, modifier = Modifier.padding(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            if (view == 0) {
                items(sold) { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.SemiBold)
                            Text(r.plu, fontSize = 12.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${r.qty} pcs", fontWeight = FontWeight.Bold)
                            Text("Rp ${rupiah(r.total)}", fontSize = 12.sp)
                        }
                    }
                    Divider()
                }
            } else {
                items(list) { s ->
                    val isOpen = s.id in open
                    val batal = s.status == 1
                    Column(
                        Modifier.fillMaxWidth()
                            .clickable { if (isOpen) open.remove(s.id) else open.add(s.id) }
                            .padding(vertical = 6.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    s.receipt + if (batal) "  BATAL" else "",
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (batal) AppRed else Color.Unspecified,
                                )
                                Text("${fmt.format(Date(s.time))} · ${s.cashier}", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(
                                "Rp ${rupiah(s.total)}", fontWeight = FontWeight.Bold,
                                color = if (batal) Color.Gray else Color.Unspecified,
                            )
                            Text(if (isOpen) "  ▲" else "  ▼", color = Color.Gray)
                        }
                        if (isOpen) {
                            val ls = remember(s.id) { db.saleLines(s.id) }
                            Column(
                                Modifier.fillMaxWidth().padding(top = 6.dp)
                                    .background(Color(0xFFF5F8FC)).padding(8.dp),
                            ) {
                                ls.forEach { l ->
                                    Row(Modifier.fillMaxWidth()) {
                                        Text("${l.qty} x ${l.name}", Modifier.weight(1f), fontSize = 13.sp)
                                        Text(rupiah(l.price * l.qty), fontSize = 13.sp)
                                    }
                                }
                                if (batal) {
                                    Text("Catatan batal: ${s.voidNote}", fontSize = 12.sp, color = AppRed)
                                    Text("Dibatalkan oleh: ${s.voidBy}", fontSize = 12.sp, color = Color.Gray)
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            "Tunai ${rupiah(s.cash)} · Kembali ${rupiah(s.change)}",
                                            Modifier.weight(1f), fontSize = 12.sp, color = Color.Gray,
                                        )
                                        TextButton(onClick = { printSale(ctx, s.id) { toast(ctx, it) } }) {
                                            Text("🖨 Cetak ulang")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun ReprintDialog(user: User, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val admin = user.rank() >= 2
    val list = remember {
        (if (admin) db.adminSales(0, 30) else db.shiftSales(user).take(30)).filter { it.status == 0 }
    }
    val qty = remember { list.associate { it.id to db.saleLines(it.id).sumOf { l -> l.qty } } }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    FullDialog("Cetak Ulang Struk", onClose) {
        Text("Ketuk transaksi untuk mencetak ulang (30 terakhir)", fontSize = 12.sp, color = Color.Gray)
        if (list.isEmpty()) Text("Belum ada transaksi", modifier = Modifier.padding(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { s ->
                Row(
                    Modifier.fillMaxWidth().clickable { printSale(ctx, s.id) { toast(ctx, it) } }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.receipt, fontWeight = FontWeight.SemiBold)
                        Text("${fmt.format(Date(s.time))} · ${s.cashier}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text(
                        (if (admin) "Rp ${rupiah(s.total)}" else "${qty[s.id] ?: 0} item") + "  🖨",
                        fontWeight = FontWeight.Bold,
                    )
                }
                Divider()
            }
        }
    }
}

@Composable
private fun CalcDialog(onClose: () -> Unit) {
    var disp by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<Char?>(null) }
    var fresh by remember { mutableStateOf(true) }

    fun fmt(d: Double) = if (d % 1.0 == 0.0 && abs(d) < 1e15) d.toLong().toString() else d.toString()
    fun calc(): Double {
        val a = acc ?: return disp.toDouble()
        val b = disp.toDouble()
        return when (op) {
            '+' -> a + b
            '-' -> a - b
            '×' -> a * b
            '÷' -> if (b == 0.0) 0.0 else a / b
            else -> b
        }
    }

    fun press(k: String) {
        when {
            k.length == 1 && k[0].isDigit() -> {
                disp = if (fresh || disp == "0") k else disp + k
                fresh = false
            }
            k == "." -> {
                if (fresh) { disp = "0."; fresh = false } else if (!disp.contains('.')) disp += "."
            }
            k == "C" -> { disp = "0"; acc = null; op = null; fresh = true }
            k == "=" -> { disp = fmt(calc()); acc = null; op = null; fresh = true }
            else -> {
                if (fresh && op != null) { op = k[0]; return }
                val r = calc()
                acc = r
                disp = fmt(r)
                op = k[0]
                fresh = true
            }
        }
    }

    FullDialog("Kalkulator", onClose) {
        Text(
            disp, fontSize = 40.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(8.dp),
        )
        val rows = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "-"),
            listOf("C", "0", ".", "+"),
        )
        rows.forEach { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                r.forEach { k ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(3.dp)
                            .background(if (k in listOf("÷", "×", "-", "+")) AppRed else Color(0xFF2B3140), RoundedCornerShape(8.dp))
                            .clickable { press(k) },
                        contentAlignment = Alignment.Center,
                    ) { Text(k, color = Color.White, fontSize = 24.sp) }
                }
            }
        }
        Button(onClick = { press("=") }, modifier = Modifier.fillMaxWidth().height(56.dp).padding(top = 6.dp)) {
            Text("=", fontSize = 22.sp)
        }
    }
}
