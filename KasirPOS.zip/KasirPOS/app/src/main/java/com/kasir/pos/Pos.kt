package com.kasir.pos

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun PosScreen(onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val user = AppState.user ?: return
    var screen by remember { mutableStateOf("pos") }
    var dialog by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var pluQuery by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    if (screen == "admin") {
        BackHandler { screen = "pos" }
        AdminScreen(onBack = { screen = "pos" })
        return
    }
    if (screen == "pay") {
        PayScreen(onBack = { screen = "pos" }, onDone = { screen = "pos" })
        return
    }

    val cart = AppState.cart
    val total = cart.sumOf { it.total }
    val qtyAll = cart.sumOf { it.qty }
    val timeFmt = remember { SimpleDateFormat("dd/MM/yy HH:mm:ss", Locale.getDefault()) }

    fun submit() {
        val t = input.trim()
        if (t.isEmpty()) return
        var qty = 1
        var code = t
        Regex("^(\\d+)\\*(.+)$").find(t)?.let {
            qty = it.groupValues[1].toInt().coerceIn(1, 9999)
            code = it.groupValues[2].trim()
        }
        val exact = db.itemByPlu(code)
        if (exact != null) {
            AppState.add(exact, qty)
            input = ""
            return
        }
        val found = db.items(code)
        if (found.size == 1) {
            AppState.add(found[0], qty)
            input = ""
        } else {
            if (found.isEmpty()) toast(ctx, "Barang tidak ditemukan")
            pluQuery = code
            dialog = "plu"
            input = ""
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        TopBar(db.getSetting("store_name", "TOKO"), user, timeFmt.format(Date(now)))
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val land = maxWidth > maxHeight
            if (land) {
                Row(Modifier.fillMaxSize()) {
                    LeftPane(
                        Modifier.weight(1f).fillMaxHeight(), input, { input = it }, { submit() },
                        { pluQuery = ""; dialog = "plu" }, { dialog = it },
                    )
                    TotalPanel(Modifier.width(300.dp).fillMaxHeight(), total, qtyAll, false) { screen = "pay" }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    LeftPane(
                        Modifier.weight(1f).fillMaxWidth(), input, { input = it }, { submit() },
                        { pluQuery = ""; dialog = "plu" }, { dialog = it },
                    )
                    TotalPanel(Modifier.fillMaxWidth(), total, qtyAll, true) { screen = "pay" }
                }
            }
        }
    }

    when (dialog) {
        "plu" -> PluDialog(pluQuery) { dialog = "" }
        "pending" -> PendingDialog { dialog = "" }
        "report" -> ReportDialog(user) { dialog = "" }
        "reprint" -> ReprintDialog(user) { dialog = "" }
        "calc" -> CalcDialog { dialog = "" }
        "more" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Tutup") } },
            title = { Text("Menu Lainnya") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (user.role == "admin") {
                        Button(onClick = { dialog = ""; screen = "admin" }, modifier = Modifier.fillMaxWidth()) {
                            Text("⚙ Pengaturan Admin")
                        }
                    }
                    OutlinedButton(
                        onClick = { AppState.cart.clear(); dialog = "" },
                        enabled = AppState.cart.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Batalkan Transaksi") }
                    OutlinedButton(onClick = { dialog = ""; onLogout() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Keluar (Logout)")
                    }
                }
            },
        )
    }
}

@Composable
private fun TopBar(store: String, user: User, time: String) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFFDCE5EF)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "🏪 $store", fontWeight = FontWeight.Bold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        Text("👤 ${user.name}", fontSize = 13.sp, maxLines = 1)
        Spacer(Modifier.width(12.dp))
        Text("🕒 $time", fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun QtyBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(28.dp).background(Color(0xFFDCE5EF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
private fun LeftPane(
    modifier: Modifier,
    input: String,
    onInput: (String) -> Unit,
    onSubmit: () -> Unit,
    onList: () -> Unit,
    onAction: (String) -> Unit,
) {
    val cart = AppState.cart
    Column(modifier.padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = onInput,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Ketik atau scan barcode / PLU di sini", fontSize = 13.sp) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onSubmit() }),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                ),
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onList,
                colors = ButtonDefaults.buttonColors(containerColor = AppRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(56.dp),
            ) { Text("☰ LIST PLU", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(8.dp))

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wide = maxWidth > 460.dp
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFFC9D6E6)).padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Spacer(Modifier.width(36.dp))
                    Text("No", Modifier.width(28.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("PLU / Nama Barang", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (wide) Text("Harga(Rp)", Modifier.width(80.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text("QTY", Modifier.width(100.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text("Total", Modifier.width(80.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                }
                if (cart.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().background(Color.White), contentAlignment = Alignment.Center) {
                        Text(
                            "Keranjang kosong\nScan barcode atau tekan LIST PLU",
                            textAlign = TextAlign.Center, color = Color.Gray,
                        )
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        itemsIndexed(cart.toList()) { i, l ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (i % 2 == 0) Color.White else Color(0xFFF5F8FC))
                                    .padding(vertical = 4.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.width(36.dp).clickable { AppState.change(i, -l.qty) },
                                    contentAlignment = Alignment.Center,
                                ) { Text("✕", color = AppRed, fontWeight = FontWeight.Bold) }
                                Text("${i + 1}", Modifier.width(28.dp), fontSize = 12.sp)
                                Column(Modifier.weight(1f)) {
                                    Text(l.item.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2)
                                    Text(
                                        l.item.plu + if (!wide) " · Rp ${rupiah(l.item.price)}" else "",
                                        fontSize = 11.sp, color = Color.Gray,
                                    )
                                }
                                if (wide) Text(rupiah(l.item.price), Modifier.width(80.dp), fontSize = 13.sp, textAlign = TextAlign.End)
                                Row(
                                    Modifier.width(100.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                ) {
                                    QtyBtn("−") { AppState.change(i, -1) }
                                    Text(
                                        "${l.qty}", Modifier.widthIn(min = 28.dp),
                                        textAlign = TextAlign.Center, fontWeight = FontWeight.Bold,
                                    )
                                    QtyBtn("+") { AppState.change(i, 1) }
                                }
                                Text(
                                    rupiah(l.total), Modifier.width(80.dp), fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End,
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        val actions = listOf(
            Triple("⏳", "Pending", "pending"),
            Triple("📊", "Lap. Sales", "report"),
            Triple("🖨", "Reprint", "reprint"),
            Triple("🧮", "Kalkulator", "calc"),
            Triple("⋯", "Lainnya", "more"),
        )
        Row(Modifier.fillMaxWidth().background(Color(0xFFDCE5EF), RoundedCornerShape(8.dp)).padding(vertical = 4.dp)) {
            actions.forEach { (icon, label, key) ->
                Column(
                    Modifier.weight(1f).clickable { onAction(key) }.padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(icon, fontSize = 20.sp)
                    val shown = if (key == "pending" && AppState.pending.isNotEmpty()) "Pending (${AppState.pending.size})" else label
                    Text(shown, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun TotalPanel(modifier: Modifier, total: Long, qty: Int, compact: Boolean, onPay: () -> Unit) {
    Column(modifier.background(Brush.verticalGradient(listOf(AppRed, DarkRed))).padding(16.dp)) {
        if (compact) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Total RP", color = Color.White, fontSize = 13.sp)
                    Text(rupiah(total), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("$qty item", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                }
                Button(
                    onClick = onPay,
                    enabled = total > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppRed),
                    modifier = Modifier.height(60.dp),
                ) { Text("PILIH\nPEMBAYARAN →", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
            }
        } else {
            Text("Total RP", color = Color.White, fontSize = 16.sp)
            Text(
                rupiah(total), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.weight(1f))
            Divider(color = Color(0x88FFFFFF))
            Spacer(Modifier.height(6.dp))
            Row {
                Text("Total $qty Item", color = Color.White, modifier = Modifier.weight(1f))
                Text("$qty", color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onPay,
                enabled = total > 0,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AppRed),
                modifier = Modifier.fillMaxWidth().height(72.dp),
            ) { Text("PILIH PEMBAYARAN →", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }
}

// ---------------------------------------------------------------- Dialogs

@Composable
private fun PluDialog(initial: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var q by remember { mutableStateOf(initial) }
    var cat by remember { mutableStateOf(-1L) }
    val cats = remember { db.categories() }
    val list = remember(q, cat) { db.items(q, cat) }
    FullDialog("List PLU", onClose) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            label = { Text("Cari nama / PLU") }, modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
            FilterChip(selected = cat == -1L, onClick = { cat = -1L }, label = { Text("Semua") })
            cats.forEach { c ->
                Spacer(Modifier.width(6.dp))
                FilterChip(selected = cat == c.id, onClick = { cat = c.id }, label = { Text(c.name) })
            }
        }
        if (list.isEmpty()) {
            Text("Tidak ada barang", color = Color.Gray, modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(list) { barang ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { AppState.add(barang, 1); toast(ctx, "+ ${barang.name}") }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(barang.name, fontWeight = FontWeight.SemiBold)
                        Text("${barang.plu} · ${barang.categoryName}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(barang.price)}", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
}

@Composable
private fun PendingDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    FullDialog("Transaksi Pending", onClose) {
        Button(
            onClick = {
                if (AppState.cart.isNotEmpty()) {
                    AppState.pending.add(AppState.cart.toList())
                    AppState.cart.clear()
                    toast(ctx, "Transaksi ditahan")
                }
            },
            enabled = AppState.cart.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Tahan transaksi saat ini") }
        Spacer(Modifier.height(8.dp))
        if (AppState.pending.isEmpty()) Text("Tidak ada transaksi pending", color = Color.Gray)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(AppState.pending.toList()) { i, p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "#${i + 1} · ${p.sumOf { it.qty }} item · Rp ${rupiah(p.sumOf { it.total })}",
                        Modifier.weight(1f),
                    )
                    TextButton(onClick = {
                        if (AppState.cart.isNotEmpty()) {
                            toast(ctx, "Tahan atau selesaikan transaksi saat ini dulu")
                        } else {
                            AppState.cart.addAll(p)
                            AppState.pending.removeAt(i)
                            onClose()
                        }
                    }) { Text("Panggil") }
                    TextButton(onClick = { AppState.pending.removeAt(i) }) { Text("Hapus", color = AppRed) }
                }
                Divider()
            }
        }
    }
}

@Composable
private fun ReportDialog(user: User, onClose: () -> Unit) {
    val db = AppState.db
    var mode by remember { mutableStateOf(0) }
    val filter = if (user.role == "admin") null else user.name
    val list = remember(mode) { db.sales(if (mode == 0) startOfDay() else startOfMonth(), filter, 500) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    FullDialog("Laporan Penjualan", onClose) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("Hari ini") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Bulan ini") })
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "${list.size} transaksi · Total Rp ${rupiah(list.sumOf { it.total })}",
            fontWeight = FontWeight.Bold, fontSize = 16.sp,
        )
        if (filter != null) Text("Hanya transaksi milik ${user.name}", fontSize = 12.sp, color = Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { s ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.receipt, fontWeight = FontWeight.SemiBold)
                        Text("${fmt.format(Date(s.time))} · ${s.cashier}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(s.total)}", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
}

@Composable
private fun ReprintDialog(user: User, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val filter = if (user.role == "admin") null else user.name
    val list = remember { db.sales(0, filter, 30) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    FullDialog("Cetak Ulang Struk", onClose) {
        Text("Ketuk transaksi untuk mencetak ulang (30 terakhir)", fontSize = 12.sp, color = Color.Gray)
        if (list.isEmpty()) Text("Belum ada transaksi", modifier = Modifier.padding(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { s ->
                Row(
                    Modifier.fillMaxWidth().clickable { printSale(ctx, s.id) { toast(ctx, it) } }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.receipt, fontWeight = FontWeight.SemiBold)
                        Text("${fmt.format(Date(s.time))} · ${s.cashier}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(s.total)}  🖨", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
}

@Composable
private fun CalcDialog(onClose: () -> Unit) {
    var disp by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<Char?>(null) }
    var fresh by remember { mutableStateOf(true) }

    fun fmt(d: Double) = if (d % 1.0 == 0.0 && abs(d) < 1e15) d.toLong().toString() else d.toString()
    fun calc(): Double {
        val a = acc ?: return disp.toDouble()
        val b = disp.toDouble()
        return when (op) {
            '+' -> a + b
            '-' -> a - b
            '×' -> a * b
            '÷' -> if (b == 0.0) 0.0 else a / b
            else -> b
        }
    }

    fun press(k: String) {
        when {
            k.length == 1 && k[0].isDigit() -> {
                disp = if (fresh || disp == "0") k else disp + k
                fresh = false
            }
            k == "." -> {
                if (fresh) { disp = "0."; fresh = false } else if (!disp.contains('.')) disp += "."
            }
            k == "C" -> { disp = "0"; acc = null; op = null; fresh = true }
            k == "=" -> { disp = fmt(calc()); acc = null; op = null; fresh = true }
            else -> {
                if (fresh && op != null) { op = k[0]; return }
                val r = calc()
                acc = r
                disp = fmt(r)
                op = k[0]
                fresh = true
            }
        }
    }

    FullDialog("Kalkulator", onClose) {
        Text(
            disp, fontSize = 40.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(8.dp),
        )
        val rows = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "-"),
            listOf("C", "0", ".", "+"),
        )
        rows.forEach { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                r.forEach { k ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(3.dp)
                            .background(if (k in listOf("÷", "×", "-", "+")) AppRed else Color(0xFF2B3140), RoundedCornerShape(8.dp))
                            .clickable { press(k) },
                        contentAlignment = Alignment.Center,
                    ) { Text(k, color = Color.White, fontSize = 24.sp) }
                }
            }
        }
        Button(onClick = { press("=") }, modifier = Modifier.fillMaxWidth().height(56.dp).padding(top = 6.dp)) {
            Text("=", fontSize = 22.sp)
        }
    }
}
