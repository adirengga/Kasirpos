package com.kasir.pos

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PayScreen(onBack: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val user = AppState.user ?: return
    val total = AppState.cart.sumOf { it.total }
    var cash by remember { mutableStateOf("") }
    var savedId by remember { mutableStateOf(0L) }
    var savedChange by remember { mutableStateOf(0L) }
    val member = AppState.member?.let { db.memberById(it.id) }
    var usePts by remember { mutableStateOf(0L) }
    val maxPts = if (member != null) minOf(member.points, total) else 0L
    val pts = usePts.coerceIn(0L, maxPts) // 1 poin = Rp 1
    val due = total - pts
    val cashVal = cash.toLongOrNull() ?: 0L
    val change = cashVal - due

    BackHandler(enabled = savedId == 0L, onBack = onBack)

    fun press(k: String) {
        when (k) {
            "Del" -> cash = cash.dropLast(1)
            "Clear" -> cash = ""
            else -> if (cash.length + k.length <= 12) cash = (cash + k).trimStart('0')
        }
    }

    fun pay() {
        if (total <= 0 || cashVal < due || savedId != 0L) return
        val lines = AppState.cart.map { SaleLine(it.item.plu, it.item.name, it.item.price, it.qty) }
        val id = db.saveSale(user.name, lines, due, cashVal, change, user.id, member, pts)
        savedChange = change
        savedId = id
        if (db.getSetting("auto_print", "1") == "1" && db.getSetting("printer_mac").isNotBlank()) {
            printSale(ctx, id) { toast(ctx, it) }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(Gold).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Cash", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Bon: ${AppState.bon} · Kasir: ${user.name}", fontSize = 12.sp, maxLines = 1)
            }
            Text("Total Rp. ${rupiah(total)}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        if (member != null && savedId == 0L) {
            Column(Modifier.fillMaxWidth().background(Color(0xFFFFF3CD)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text("Member: ${member.name} · Poin ${rupiah(member.points)}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = if (usePts == 0L) "" else usePts.toString(),
                        onValueChange = { usePts = it.filter { c -> c.isDigit() }.take(9).toLongOrNull() ?: 0L },
                        label = { Text("Potong poin (100 poin = Rp 100)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = { usePts = maxPts }) { Text("Maks") }
                    OutlinedButton(onClick = { usePts = 0 }) { Text("0") }
                }
                if (pts > 0) {
                    Text(
                        "Potongan Rp ${rupiah(pts)} → Bayar Rp ${rupiah(due)}",
                        fontWeight = FontWeight.Bold, fontSize = 14.sp, color = AppRed,
                    )
                }
            }
        }

        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val land = maxWidth > maxHeight
            if (land) {
                Row(Modifier.fillMaxSize()) {
                    InfoPane(Modifier.weight(1f).fillMaxHeight(), due, cashVal, change) { cash = it.toString() }
                    NumPad(Modifier.weight(1f).fillMaxHeight().padding(8.dp)) { press(it) }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    InfoPane(Modifier.fillMaxWidth(), due, cashVal, change) { cash = it.toString() }
                    NumPad(Modifier.weight(1f).fillMaxWidth().padding(8.dp)) { press(it) }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).height(56.dp)) { Text("← KEMBALI") }
            Button(
                onClick = { pay() },
                enabled = total > 0 && cashVal >= due,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.weight(2f).height(56.dp),
            ) { Text("BAYAR", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        }
    }

    if (savedId != 0L) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Pembayaran Berhasil") },
            text = {
                Column {
                    Text("Bon ${db.sale(savedId)?.receipt ?: ""}", fontSize = 12.sp)
                    Text("Kembalian")
                    Text("Rp ${rupiah(savedChange)}", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Green)
                    db.sale(savedId)?.takeIf { it.memberName.isNotBlank() }?.let {
                        Spacer(Modifier.height(8.dp))
                        Text("Member: ${it.memberName}", fontSize = 13.sp)
                        Text("Poin bertambah ${rupiah(it.ptsEarned)} · saat ini ${rupiah(it.ptsBalance)}", fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { AppState.cart.clear(); AppState.member = null; onDone() }) { Text("SELESAI") }
            },
            dismissButton = {
                OutlinedButton(onClick = { printSale(ctx, savedId) { toast(ctx, it) } }) { Text("Cetak Struk") }
            },
        )
    }
}

@Composable
private fun InfoPane(modifier: Modifier, total: Long, cash: Long, change: Long, onQuick: (Long) -> Unit) {
    Column(modifier.padding(12.dp)) {
        Text("Uang Tunai Konsumen", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { onQuick(total) }) { Text("Uang Pas") }
            listOf(5000L, 10000L, 20000L, 50000L, 100000L).forEach { v ->
                OutlinedButton(onClick = { onQuick(v) }) { Text(rupiah(v)) }
            }
        }
        Text("Pembayaran Tunai", fontSize = 12.sp, color = Color(0xFF2B6CB0))
        Box(
            Modifier.fillMaxWidth().height(72.dp)
                .background(Color.White, RoundedCornerShape(8.dp))
                .border(BorderStroke(1.dp, Color(0xFF2B6CB0)), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterEnd,
        ) {
            Text(
                if (cash == 0L) "0" else rupiah(cash),
                fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2B6CB0),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row {
            Text(if (change >= 0) "Kembalian" else "Kurang", modifier = Modifier.weight(1f), fontSize = 16.sp)
            Text(
                "Rp ${rupiah(kotlin.math.abs(change))}", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                color = if (change >= 0) Green else AppRed, textAlign = TextAlign.End,
            )
        }
    }
}

@Composable
private fun NumPad(modifier: Modifier, onKey: (String) -> Unit) {
    val rows = listOf(
        listOf("7", "8", "9"),
        listOf("4", "5", "6"),
        listOf("1", "2", "3"),
        listOf("0", "00", "000"),
        listOf("Del", "Clear"),
    )
    Column(modifier.heightIn(min = 240.dp)) {
        rows.forEach { r ->
            Row(Modifier.weight(1f).fillMaxWidth()) {
                r.forEach { k ->
                    Box(
                        Modifier.weight(1f).fillMaxHeight().padding(3.dp)
                            .background(if (k == "Del" || k == "Clear") AppRed else Color(0xFF2B3140), RoundedCornerShape(8.dp))
                            .clickable { onKey(k) },
                        contentAlignment = Alignment.Center,
                    ) { Text(k, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium) }
                }
            }
        }
    }
}
