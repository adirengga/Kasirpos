package com.kasir.pos

import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Tabel laporan generik: satu bentuk data untuk layar, cetak thermal, dan file XLSX.
 * Sel berisi String atau angka (Long/Int). Kolom di [moneyCols] ditampilkan sebagai rupiah.
 */
data class RTable(
    val title: String,
    val info: List<String>,
    val headers: List<String>,
    val rows: List<List<Any>>,
    val moneyCols: Set<Int> = emptySet(),
    val totals: List<List<Any>> = emptyList(),
    val fileName: String = "report",
)

/** Rupiah bertanda; [plus] menambah "+" untuk nilai positif. */
fun rupiahSigned(v: Long, plus: Boolean = false): String = (if (plus && v > 0) "+" else "") + rupiah(v)

fun RTable.cellText(row: List<Any>, col: Int): String {
    val v = row.getOrNull(col) ?: return ""
    return when {
        v is Long && col in moneyCols -> rupiahSigned(v)
        else -> v.toString()
    }
}

object Rep {
    const val SHIFT = "shift"
    const val DAILY = "daily"
    const val SALES = "sales"
    const val VOIDS = "voids"

    private fun fmt(p: String) = SimpleDateFormat(p, Locale.getDefault())

    fun startOfDay(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun addDays(t: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.add(Calendar.DAY_OF_MONTH, n)
        return c.timeInMillis
    }

    fun addMonths(t: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.add(Calendar.MONTH, n)
        return c.timeInMillis
    }

    fun dayRange(t: Long): Pair<Long, Long> = startOfDay(t).let { it to addDays(it, 1) }

    fun monthStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = startOfDay(t)
        c.set(Calendar.DAY_OF_MONTH, 1)
        return c.timeInMillis
    }

    fun yearStart(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = startOfDay(t)
        c.set(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun dayLabel(t: Long): String = fmt("EEEE, dd MMM yyyy").format(Date(t))

    /** Rentang data yang dibutuhkan laporan penjualan. mode: "day" | "week" | "month". */
    fun salesRange(mode: String, anchor: Long): Pair<Long, Long> =
        if (mode == "month") {
            val y = yearStart(anchor)
            val c = Calendar.getInstance(); c.timeInMillis = y; c.add(Calendar.YEAR, 1)
            y to c.timeInMillis
        } else {
            val m = monthStart(anchor)
            m to addMonths(m, 1)
        }

    private fun nameOf(s: ShiftRow) = s.name.ifBlank { s.username }

    /** 1) Hasil tutup shift per kasir pada satu hari. */
    fun shiftTable(day: Long, shifts: List<ShiftRow>): RTable {
        val f = fmt("HH:mm")
        val rows = shifts.sortedWith(compareBy({ nameOf(it).lowercase() }, { it.endTime })).map {
            listOf<Any>(nameOf(it), it.username, f.format(Date(it.endTime)), it.txCount, it.counted, it.expected, it.diff, it.voidCount, it.authBy)
        }
        return RTable(
            title = "Hasil Tutup Shift per Kasir",
            info = listOf("Tanggal: " + dayLabel(day)),
            headers = listOf("Kasir", "User", "Jam Tutup", "Transaksi", "Disetor (fisik)", "Harus Disetor", "Selisih", "Batal", "Disetujui"),
            rows = rows,
            moneyCols = setOf(4, 5, 6),
            fileName = "tutup-shift-" + fmt("yyyyMMdd").format(Date(day)),
        )
    }

    /** 2) Total uang 1 hari dari shift yang sudah ditutup: hitung per kasir lalu dijumlahkan. */
    fun dailyTable(day: Long, shifts: List<ShiftRow>): RTable {
        val groups = shifts.groupBy { it.userId to nameOf(it) }
        val rows = groups.entries.sortedBy { it.key.second.lowercase() }.map { (k, list) ->
            listOf<Any>(
                k.second, list.size, list.sumOf { it.txCount },
                list.sumOf { it.expected }, list.sumOf { it.counted }, list.sumOf { it.counted - it.expected },
            )
        }
        val tot = listOf<Any>(
            "TOTAL", rows.sumOf { it[1] as Int }, rows.sumOf { it[2] as Int },
            rows.sumOf { it[3] as Long }, rows.sumOf { it[4] as Long }, rows.sumOf { it[5] as Long },
        )
        return RTable(
            title = "Total Uang Harian (Shift Ditutup)",
            info = listOf("Tanggal: " + dayLabel(day), "Hanya shift yang sudah ditutup"),
            headers = listOf("Kasir", "Shift", "Transaksi", "Harus Disetor", "Disetor (fisik)", "Selisih"),
            rows = rows,
            moneyCols = setOf(3, 4, 5),
            totals = listOf(tot),
            fileName = "total-harian-" + fmt("yyyyMMdd").format(Date(day)),
        )
    }

    /** 3) Total penjualan harian / mingguan / bulanan. [sales] = transaksi sah dalam [salesRange]. */
    fun salesTable(mode: String, anchor: Long, sales: List<SalesLite>): RTable {
        val rows = mutableListOf<List<Any>>()
        val title: String
        val info: String
        val first: String
        val name: String
        when (mode) {
            "month" -> {
                title = "Penjualan Bulanan"; first = "Bulan"
                info = "Tahun " + fmt("yyyy").format(Date(anchor))
                name = "penjualan-bulanan-" + fmt("yyyy").format(Date(anchor))
                var m = yearStart(anchor)
                repeat(12) {
                    val n = addMonths(m, 1)
                    val l = sales.filter { it.time in m until n }
                    rows.add(listOf(fmt("MMMM yyyy").format(Date(m)), l.size, l.sumOf { it.qty }, l.sumOf { it.total }))
                    m = n
                }
            }
            "week" -> {
                title = "Penjualan Mingguan"; first = "Minggu"
                val ms = monthStart(anchor); val me = addMonths(ms, 1)
                info = "Bulan " + fmt("MMMM yyyy").format(Date(ms)) + " (Senin-Minggu)"
                name = "penjualan-mingguan-" + fmt("yyyyMM").format(Date(ms))
                var a = ms
                val d = fmt("dd/MM")
                while (a < me) {
                    val c = Calendar.getInstance(); c.timeInMillis = a
                    val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Senin = 0
                    val b = minOf(addDays(a, 7 - dow), me)
                    val l = sales.filter { it.time in a until b }
                    rows.add(listOf(d.format(Date(a)) + " - " + d.format(Date(addDays(b, -1))), l.size, l.sumOf { it.qty }, l.sumOf { it.total }))
                    a = b
                }
            }
            else -> {
                title = "Penjualan Harian"; first = "Tanggal"
                val ms = monthStart(anchor); val me = addMonths(ms, 1)
                info = "Bulan " + fmt("MMMM yyyy").format(Date(ms))
                name = "penjualan-harian-" + fmt("yyyyMM").format(Date(ms))
                var a = ms
                val d = fmt("EEE dd/MM")
                while (a < me) {
                    val b = addDays(a, 1)
                    val l = sales.filter { it.time in a until b }
                    rows.add(listOf(d.format(Date(a)), l.size, l.sumOf { it.qty }, l.sumOf { it.total }))
                    a = b
                }
            }
        }
        val tot = listOf<Any>("TOTAL", rows.sumOf { it[1] as Int }, rows.sumOf { it[2] as Int }, rows.sumOf { it[3] as Long })
        return RTable(
            title = title, info = listOf(info, "Transaksi sah (tidak termasuk yang dibatalkan)"),
            headers = listOf(first, "Transaksi", "Item", "Total Penjualan"),
            rows = rows, moneyCols = setOf(3), totals = listOf(tot), fileName = name,
        )
    }

    /** 4) Transaksi batal / dihapus per kasir dalam 1 hari. */
    fun voidTable(day: Long, voided: List<SaleRow>, carts: List<CartVoidRow>): RTable {
        val f = fmt("HH:mm")
        class R(val cashier: String, val time: Long, val cells: List<Any>)
        val all = mutableListOf<R>()
        voided.forEach {
            all.add(R(it.cashier, it.voidTime, listOf(it.cashier, f.format(Date(it.voidTime)), "Hapus transaksi", "Bon " + it.receipt, it.total, it.voidNote, it.voidBy)))
        }
        carts.forEach {
            val jenis = if (it.kind == "cancel") "Batal transaksi" else "Hapus item"
            all.add(R(it.cashier, it.time, listOf(it.cashier, f.format(Date(it.time)), jenis, it.detail, it.amount, it.note, it.authBy)))
        }
        val rows = all.sortedWith(compareBy({ it.cashier.lowercase() }, { it.time })).map { it.cells }
        val tot = listOf<Any>("TOTAL", "", "${rows.size} kejadian", "", rows.sumOf { it[4] as Long }, "", "")
        return RTable(
            title = "Transaksi Batal / Dihapus",
            info = listOf("Tanggal: " + dayLabel(day), "Per kasir; termasuk batal sebelum bayar & hapus item"),
            headers = listOf("Kasir", "Jam", "Jenis", "Detail", "Nilai", "Catatan", "Disetujui"),
            rows = rows, moneyCols = setOf(4), totals = listOf(tot),
            fileName = "transaksi-batal-" + fmt("yyyyMMdd").format(Date(day)),
        )
    }
}

/** Penulis XLSX minimal (tanpa library): sheet tunggal, header tebal, angka bernilai numerik. */
object Xlsx {
    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\n' || ch == '\t' || ch.code >= 32 -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun col(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    private fun str(ref: String, s: String, style: Int) =
        "<c r=\"$ref\" t=\"inlineStr\" s=\"$style\"><is><t xml:space=\"preserve\">${esc(s)}</t></is></c>"

    private fun cell(ref: String, v: Any, money: Boolean, bold: Boolean): String {
        val st = if (bold) (if (money) 3 else 1) else (if (money) 2 else 0)
        return if ((v is Long || v is Int) && (money || v is Int)) {
            "<c r=\"$ref\" s=\"${if (bold) 3 else if (money) 2 else 0}\"><v>$v</v></c>"
        } else str(ref, v.toString(), st)
    }

    fun build(t: RTable): ByteArray {
        val sheet = StringBuilder()
        sheet.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sheet.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sheet.append("<cols><col min=\"1\" max=\"${t.headers.size}\" width=\"22\" customWidth=\"1\"/></cols><sheetData>")
        var r = 1
        sheet.append("<row r=\"$r\">${str("A$r", t.title, 1)}</row>"); r++
        t.info.forEach { sheet.append("<row r=\"$r\">${str("A$r", it, 0)}</row>"); r++ }
        r++
        sheet.append("<row r=\"$r\">")
        t.headers.forEachIndexed { i, h -> sheet.append(str(col(i) + r, h, 1)) }
        sheet.append("</row>"); r++
        t.rows.forEach { row ->
            sheet.append("<row r=\"$r\">")
            t.headers.indices.forEach { i -> sheet.append(cell(col(i) + r, row.getOrNull(i) ?: "", i in t.moneyCols, false)) }
            sheet.append("</row>"); r++
        }
        t.totals.forEach { row ->
            sheet.append("<row r=\"$r\">")
            t.headers.indices.forEach { i -> sheet.append(cell(col(i) + r, row.getOrNull(i) ?: "", i in t.moneyCols, true)) }
            sheet.append("</row>"); r++
        }
        sheet.append("</sheetData></worksheet>")

        val styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"4\">" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"3\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
            "<xf numFmtId=\"3\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\"/>" +
            "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"

        val files = linkedMapOf(
            "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>",
            "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>",
            "xl/workbook.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Report\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>",
            "xl/_rels/workbook.xml.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>",
            "xl/styles.xml" to styles,
            "xl/worksheets/sheet1.xml" to sheet.toString(),
        )
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            files.forEach { (n, c) ->
                z.putNextEntry(ZipEntry(n))
                z.write(c.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }
}
