package com.kasir.pos

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val btLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.init(this)
        AppState.askBt = {
            if (Build.VERSION.SDK_INT >= 31) btLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
        setContent {
            KasirTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (AppState.user == null) {
                        LoginScreen()
                    } else {
                        PosScreen(onLogout = {
                            AppState.cart.clear()
                            AppState.user = null
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen() {
    val ctx = LocalContext.current
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }

    fun go() {
        val r = AppState.db.login(u, p)
        if (r == null) toast(ctx, "Username atau password salah") else AppState.user = r
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(AppRed, DarkRed))).systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth().padding(16.dp),
        ) {
            Column(
                Modifier.padding(24.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Point of Sales", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = AppRed)
                Text(AppState.db.getSetting("store_name"), fontSize = 14.sp, color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Field("Username", u, { u = it })
                OutlinedTextField(
                    value = p,
                    onValueChange = { p = it },
                    label = { Text("Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { go() }),
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { go() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("MASUK") }
                Spacer(Modifier.height(8.dp))
                Text("Login awal: admin / admin", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}
