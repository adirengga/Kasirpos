package com.kasir.pos

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val btLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.init(this)
        AppState.askBt = {
            if (Build.VERSION.SDK_INT >= 31) {
                btLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
            }
        }
        setContent {
            LaunchedEffect(Unit) {
                snapshotFlow { AppState.heldJson() }.collect { AppState.db.setSetting("held_state", it) }
            }
            KasirTheme {
                Surface(Modifier.fillMaxSize()) {
                    val tool = AppState.tool
                    if (AppState.user != null && tool == "reports") {
                        ReportsScreen(onBack = { AppState.tool = null; AppState.user = null })
                    } else if (AppState.user != null && tool == "admin") {
                        AdminScreen(onBack = { AppState.tool = null; AppState.user = null })
                    } else if (AppState.user == null) {
                        LoginScreen()
                    } else {
                        PosScreen(onLogout = { AppState.logoutKeepCart() })
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen() {
    val ctx = LocalContext.current
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf<String?>(null) }

    fun go() {
        val r = AppState.db.login(u, p)
        if (r == null) {
            toast(ctx, "Username atau password salah")
        } else {
            val b = AppState.loginBlocker(r)
            if (b != null) {
                toast(ctx, "Kasir $b belum tutup shift. Login sebagai $b lalu Tutup Shift dulu.")
            } else {
                AppState.tool = null
                AppState.user = r
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(AppRed, DarkRed))).systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth().padding(16.dp),
        ) {
            Column(
                Modifier.padding(24.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Point of Sales", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = AppRed)
                Text(AppState.db.getSetting("store_name"), fontSize = 14.sp, color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Field("Username", u, { u = it })
                OutlinedTextField(
                    value = p,
                    onValueChange = { p = it },
                    label = { Text("Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { go() }),
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { go() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("MASUK") }
                Spacer(Modifier.height(8.dp))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { ask = "reports" }, modifier = Modifier.weight(1f)) { Text("📈 Report") }
                    OutlinedButton(onClick = { ask = "admin" }, modifier = Modifier.weight(1f)) { Text("⚙ Pengaturan") }
                }
            }
        }
    }

    val k = ask
    if (k != null) {
        val admin = k == "admin"
        AuthDialog(
            title = if (admin) "Pengaturan (Admin)" else "Report (Staff/Admin)",
            description = if (admin) "Masuk dengan akun Admin untuk mengatur barang, menu, struk, printer, user, dan backup."
            else "Masuk dengan akun Staff atau Admin untuk membuka report.",
            user = null, noteLabel = null, noteRequired = false, confirmText = "BUKA",
            onClose = { ask = null },
            onAuthorized = { a, _ ->
                if (admin && a.rank() < 2) {
                    toast(ctx, "Pengaturan hanya untuk level Admin")
                } else {
                    AppState.user = a
                    AppState.tool = k
                    ask = null
                }
            },
        )
    }
}
