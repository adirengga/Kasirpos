package com.kasir.pos

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun shiftDate(t: Long): String = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(t))

fun authLabel(u: User): String = "${u.name} (${u.username})"

private const val AUTH_FAIL = "Username/password salah atau level kurang (minimal Staff)"

@Composable
private fun InfoRow(label: String, value: String, color: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.weight(1f), fontSize = 13.sp, color = Color.Gray)
        Spacer(Modifier.width(8.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color, textAlign = TextAlign.End)
    }
}

private fun diffText(diff: Long): String {
    val tag = when {
        diff > 0 -> " (lebih)"
        diff < 0 -> " (kurang)"
        else -> " (sesuai)"
    }
    return (if (diff > 0) "+" else "") + "Rp ${rupiah(diff)}" + tag
}

// ------------------------------------------------------------------ Otorisasi staff

/**
 * Dialog otorisasi: username + password minimal level Staff (+ catatan opsional/wajib).
 * [onAuthorized] menerima user yang menyetujui dan catatannya; pemanggil yang menutup dialog.
 */
@Composable
fun AuthDialog(
    title: String,
    description: String,
    user: User?,
    noteLabel: String?,
    noteRequired: Boolean,
    confirmText: String,
    onClose: () -> Unit,
    onAuthorized: (User, String) -> Unit,
) {
    val ctx = LocalContext.current
    val db = AppState.db
    var username by remember { mutableStateOf(if (user != null && user.rank() >= 1) user.username else "") }
    var pass by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(description, fontSize = 13.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Text("Otorisasi (minimal Staff)", fontWeight = FontWeight.Bold)
                Field("Username / NIK", username, { username = it.trim() })
                Field("Password", pass, { pass = it }, password = true)
                if (noteLabel != null) Field(noteLabel, note, { note = it }, minLines = 2)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val a = db.authorize(username, pass)
                    when {
                        noteRequired && note.trim().length < 3 -> toast(ctx, "Catatan/alasan wajib diisi")
                        a == null -> toast(ctx, AUTH_FAIL)
                        else -> onAuthorized(a, note.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppRed),
            ) { Text(confirmText, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } },
    )
}

// ------------------------------------------------------------------ Hapus transaksi

/**
 * Hapus (batalkan) transaksi pada shift yang belum ditutup.
 * Wajib: username + password minimal level Staff, dan catatan/alasan.
 */
@Composable
fun VoidDialog(user: User, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    val admin = user.rank() >= 2
    var tick by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<SaleRow?>(null) }
    var username by remember { mutableStateOf(if (user.rank() >= 1) user.username else "") }
    var pass by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val list = remember(tick) {
        if (admin) db.adminSales(0, 1000).filter { it.shiftId == 0L && it.status == 0 }
        else db.shiftSales(user).filter { it.status == 0 }
    }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    val sel = selected

    FullDialog(if (sel == null) "Hapus Transaksi" else "Hapus ${sel.receipt}", onClose) {
        if (sel == null) {
            Text(
                "Pilih transaksi yang akan dihapus. Hanya transaksi pada shift yang belum ditutup.",
                fontSize = 12.sp, color = Color.Gray,
            )
            if (list.isEmpty()) Text("Tidak ada transaksi", color = Color.Gray, modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(list) { s ->
                    val ls = remember(s.id) { db.saleLines(s.id) }
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { selected = s; pass = ""; note = "" }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(s.receipt, fontWeight = FontWeight.SemiBold)
                            Text("${fmt.format(Date(s.time))} · ${s.cashier}", fontSize = 12.sp, color = Color.Gray)
                            Text(ls.joinToString(", ") { "${it.qty}x ${it.name}" }, fontSize = 12.sp, maxLines = 2)
                        }
                        if (admin) Text("Rp ${rupiah(s.total)}", fontWeight = FontWeight.Bold)
                    }
                    Divider()
                }
            }
        } else {
            val ls = remember(sel.id) { db.saleLines(sel.id) }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text("${fmt.format(Date(sel.time))} · Kasir ${sel.cashier}", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                ls.forEach { l -> Text("${l.qty} x ${l.name}", fontSize = 14.sp) }
                if (admin) Text("Total Rp ${rupiah(sel.total)}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                Divider(Modifier.padding(vertical = 8.dp))
                Text("Otorisasi (minimal Staff)", fontWeight = FontWeight.Bold)
                Field("Username / NIK", username, { username = it.trim() })
                Field("Password", pass, { pass = it }, password = true)
                Field("Catatan / alasan (wajib)", note, { note = it }, minLines = 2)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { selected = null }, modifier = Modifier.weight(1f)) { Text("Kembali") }
                Button(
                    onClick = {
                        val a = db.authorize(username, pass)
                        when {
                            note.trim().length < 3 -> toast(ctx, "Catatan/alasan wajib diisi")
                            a == null -> toast(ctx, AUTH_FAIL)
                            else -> {
                                val err = db.voidSale(sel.id, authLabel(a), note)
                                if (err != null) {
                                    toast(ctx, err)
                                } else {
                                    toast(ctx, "Transaksi dihapus")
                                    selected = null
                                    pass = ""
                                    note = ""
                                    tick++
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppRed),
                    modifier = Modifier.weight(1f),
                ) { Text("HAPUS", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

// ------------------------------------------------------------------ Tutup shift

/**
 * Tutup shift milik [user]: masukkan uang di laci, lalu user+password minimal Staff.
 * Setelah itu muncul hasilnya beserta tombol print. [onFinish] dipanggil saat hasil ditutup.
 */
@Composable
fun ShiftDialog(user: User, onFinish: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var step by remember { mutableStateOf(0) }
    var cash by remember { mutableStateOf("") }
    var username by remember { mutableStateOf(if (user.rank() >= 1) user.username else "") }
    var pass by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ShiftRow?>(null) }
    val res = result

    if (res != null) {
        FullDialog("Hasil Tutup Shift", onFinish) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                ShiftResult(res)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton(
                    onClick = { printShift(ctx, res.id) { toast(ctx, it) } },
                    modifier = Modifier.weight(1f).height(52.dp),
                ) { Text("🖨 Print") }
                Button(onClick = onFinish, modifier = Modifier.weight(1f).height(52.dp)) { Text("Selesai & Keluar") }
            }
        }
        return
    }

    val cartBusy = AppState.cart.isNotEmpty()
    val pendingN = AppState.pending.size
    val blocked = cartBusy || pendingN > 0
    FullDialog("Tutup Shift", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text("Kasir: ${user.name} (${user.username})", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (blocked) {
                if (cartBusy) {
                    Text(
                        "Masih ada transaksi di keranjang. Selesaikan (bayar & cetak struk) atau batalkan dulu sebelum tutup shift.",
                        color = AppRed, fontSize = 13.sp,
                    )
                }
                if (pendingN > 0) {
                    Text(
                        "Masih ada $pendingN transaksi pending. Selesaikan (bayar & cetak struk) atau hapus dulu sebelum tutup shift.",
                        color = AppRed, fontSize = 13.sp,
                        modifier = Modifier.padding(top = if (cartBusy) 6.dp else 0.dp),
                    )
                }
            } else if (step == 0) {
                Text("Hitung uang fisik di laci, lalu masukkan jumlahnya.", fontSize = 13.sp, color = Color.Gray)
                Field("Jumlah uang di laci (Rp)", cash, { cash = it.filter { c -> c.isDigit() }.take(12) }, number = true)
            } else {
                Text("Uang di laci: Rp ${rupiah(cash.toLongOrNull() ?: 0L)}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Text("Otorisasi (minimal Staff)", fontWeight = FontWeight.Bold)
                Field("Username / NIK", username, { username = it.trim() })
                Field("Password", pass, { pass = it }, password = true)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            if (step == 1) {
                OutlinedButton(onClick = { step = 0 }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Kembali") }
            }
            Button(
                onClick = {
                    if (step == 0) {
                        if (cash.isBlank()) toast(ctx, "Isi jumlah uang di laci (isi 0 jika kosong)") else step = 1
                    } else {
                        val a = db.authorize(username, pass)
                        if (a == null) {
                            toast(ctx, AUTH_FAIL)
                        } else {
                            result = db.closeShift(user, cash.toLongOrNull() ?: 0L, authLabel(a))
                        }
                    }
                },
                enabled = !blocked,
                modifier = Modifier.weight(1f).height(52.dp),
            ) { Text(if (step == 0) "LANJUT" else "TUTUP SHIFT", fontWeight = FontWeight.Bold) }
        }
    }
}

/** Isi hasil tutup shift (tanpa scroll sendiri; pemanggil yang mengatur scroll). */
@Composable
fun ShiftResult(s: ShiftRow) {
    val db = AppState.db
    val voids = remember(s.id) { db.shiftEvents(s) }
    Column(Modifier.fillMaxWidth()) {
        InfoRow("Nama", s.name)
        InfoRow("User", s.username)
        InfoRow("Tanggal", shiftDate(s.endTime))
        InfoRow("Periode", shiftDate(s.startTime) + " s/d " + shiftDate(s.endTime))
        Divider(Modifier.padding(vertical = 6.dp))
        InfoRow("Uang yang di setor (uang fisik)", "Rp ${rupiah(s.counted)}")
        InfoRow("Uang yang harus di setor (sesuai data)", "Rp ${rupiah(s.expected)}")
        InfoRow("Selisih", diffText(s.diff), if (s.diff == 0L) Green else AppRed)
        InfoRow("Jumlah transaksi", "${s.txCount}")
        InfoRow("Disetujui oleh", s.authBy)
        Divider(Modifier.padding(vertical = 6.dp))
        Text("Transaksi batal / dihapus (${voids.size})", fontWeight = FontWeight.Bold)
        if (voids.isEmpty()) Text("Tidak ada transaksi batal", fontSize = 13.sp, color = Color.Gray)
        voids.forEach { v ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${v.kind} · ${shiftDate(v.time)}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("${v.detail} · Rp ${rupiah(v.amount)}", fontSize = 13.sp)
                if (v.note.isNotBlank()) Text("Catatan: ${v.note}", fontSize = 13.sp)
                Text("Disetujui oleh: ${v.by}", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

// ------------------------------------------------------------------ Tab Shift (admin)

@Composable
fun ShiftsTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    var mode by remember { mutableStateOf(0) }
    var openId by remember { mutableStateOf(0L) }
    val from = when (mode) {
        0 -> startOfDay()
        1 -> startOfMonth()
        else -> 0L
    }
    val list = remember(mode) { db.shifts(from, 500) }
    val sumCounted = list.sumOf { it.counted }
    val sumExpected = list.sumOf { it.expected }
    val sumDiff = list.sumOf { it.diff }

    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("Hari ini") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Bulan ini") })
            FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("Semua") })
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxWidth().background(Color.White).padding(10.dp)) {
            Text("${list.size} shift ditutup", fontWeight = FontWeight.Bold)
            InfoRow("Total uang disetor (fisik)", "Rp ${rupiah(sumCounted)}")
            InfoRow("Total seharusnya disetor", "Rp ${rupiah(sumExpected)}")
            InfoRow("Total selisih", diffText(sumDiff), if (sumDiff == 0L) Green else AppRed)
        }
        Spacer(Modifier.height(4.dp))
        if (list.isEmpty()) Text("Belum ada shift yang ditutup", color = Color.Gray, modifier = Modifier.padding(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { s ->
                val isOpen = openId == s.id
                Column(
                    Modifier.fillMaxWidth()
                        .clickable { openId = if (isOpen) 0L else s.id }
                        .padding(vertical = 8.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${s.name} (${s.username})", fontWeight = FontWeight.SemiBold)
                            Text(shiftDate(s.endTime), fontSize = 12.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Rp ${rupiah(s.expected)}", fontWeight = FontWeight.Bold)
                            Text(
                                if (s.diff == 0L) "Sesuai" else "Selisih ${rupiah(s.diff)}",
                                fontSize = 12.sp, color = if (s.diff == 0L) Green else AppRed,
                            )
                        }
                        Text(if (isOpen) "  ▲" else "  ▼", color = Color.Gray)
                    }
                    if (isOpen) {
                        Column(
                            Modifier.fillMaxWidth().padding(top = 6.dp)
                                .background(Color(0xFFF5F8FC)).padding(10.dp),
                        ) {
                            ShiftResult(s)
                            OutlinedButton(
                                onClick = { printShift(ctx, s.id) { toast(ctx, it) } },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            ) { Text("🖨 Print") }
                        }
                    }
                }
                Divider()
            }
        }
    }
}
