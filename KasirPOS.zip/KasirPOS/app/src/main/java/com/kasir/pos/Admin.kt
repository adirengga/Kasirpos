package com.kasir.pos

import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScreen(onBack: () -> Unit) {
    val rank = AppState.user?.rank() ?: 0
    var tab by remember { mutableStateOf(0) }
    // Admin: semua menu. Staff: hanya user kasir & printer (tidak bisa barang, struk, backup/restore).
    val tabs = if (rank >= 2) {
        listOf("Barang", "Menu", "User Kasir", "Printer", "Struk", "Shift", "Backup")
    } else {
        listOf("User Kasir", "Printer")
    }
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(AppRed).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("← Kembali", color = Color.White) }
            Text(if (rank >= 2) "Pengaturan Admin" else "Pengaturan Staff", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEachIndexed { i, t ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
            when (tabs.getOrNull(tab)) {
                "Barang" -> ItemsTab()
                "Menu" -> CategoriesTab()
                "User Kasir" -> UsersTab()
                "Printer" -> PrinterTab()
                "Struk" -> StrukTab()
                "Shift" -> ShiftsTab()
                "Backup" -> BackupTab()
                else -> {}
            }
        }
    }
}

// ------------------------------------------------------------------ Barang

@Composable
private fun ItemsTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Item?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick, q) { db.items(q) }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Cari barang / PLU") }, modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { adding = true }) { Text("+ Barang") }
        }
        Text("${list.size} barang · ketuk untuk ubah", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { b ->
                Row(
                    Modifier.fillMaxWidth().clickable { edit = b }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(b.name, fontWeight = FontWeight.SemiBold)
                        Text("${b.plu} · ${b.categoryName}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(b.price)}", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        ItemDialog(edit, onClose = { adding = false; edit = null }, onSaved = { tick++ })
    }
}

@Composable
private fun ItemDialog(item: Item?, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var plu by remember { mutableStateOf(item?.plu ?: "") }
    var name by remember { mutableStateOf(item?.name ?: "") }
    var price by remember { mutableStateOf(item?.price?.toString() ?: "") }
    var cat by remember { mutableStateOf(item?.categoryId ?: 0L) }
    val cats = remember { db.categories() }
    val catName = cats.firstOrNull { it.id == cat }?.name ?: "Tanpa menu"

    FullDialog(if (item == null) "Tambah Barang" else "Ubah Barang", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("PLU / Barcode", plu, { plu = it })
            Field("Nama barang", name, { name = it })
            Field("Harga (Rp)", price, { price = it.filter { c -> c.isDigit() }.take(12) }, number = true)
            Picker(
                "Menu", catName,
                listOf("0" to "Tanpa menu") + cats.map { it.id.toString() to it.name },
            ) { cat = it.toLong() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            if (item != null) {
                OutlinedButton(onClick = { db.deleteItem(item.id); onSaved(); onClose() }) {
                    Text("Hapus", color = AppRed)
                }
            }
            Button(
                onClick = {
                    val p = price.toLongOrNull()
                    when {
                        plu.isBlank() || name.isBlank() -> toast(ctx, "PLU dan nama wajib diisi")
                        p == null -> toast(ctx, "Harga tidak valid")
                        !db.saveItem(item?.id ?: 0L, plu, name, p, cat) -> toast(ctx, "PLU sudah dipakai barang lain")
                        else -> { onSaved(); onClose() }
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Simpan") }
        }
    }
}

// ------------------------------------------------------------------ Menu (kategori)

@Composable
private fun CategoriesTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<Category?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick) { db.categories() }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { adding = true }) { Text("+ Menu / Kategori") }
        Text("Dipakai untuk mengelompokkan barang di LIST PLU", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { c ->
                Row(Modifier.fillMaxWidth().clickable { edit = c }.padding(vertical = 14.dp)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("Ubah", color = AppRed)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        val c = edit
        var name by remember(c) { mutableStateOf(c?.name ?: "") }
        AlertDialog(
            onDismissRequest = { adding = false; edit = null },
            title = { Text(if (c == null) "Tambah Menu" else "Ubah Menu") },
            text = { Field("Nama menu", name, { name = it }) },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        db.saveCategory(c?.id ?: 0L, name)
                        tick++
                        adding = false; edit = null
                    }
                }) { Text("Simpan") }
            },
            dismissButton = {
                Row {
                    if (c != null) {
                        TextButton(onClick = { db.deleteCategory(c.id); tick++; edit = null }) {
                            Text("Hapus", color = AppRed)
                        }
                    }
                    TextButton(onClick = { adding = false; edit = null }) { Text("Batal") }
                }
            },
        )
    }
}

// ------------------------------------------------------------------ User

@Composable
private fun UsersTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<User?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick) { db.users() }
    val canEdit = (AppState.user?.rank() ?: 0) >= 2

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { adding = true }) { Text(if (canEdit) "+ User" else "+ User Kasir") }
        if (!canEdit) {
            Text("Staff hanya dapat mendaftarkan user dengan level Kasir.", fontSize = 12.sp, color = Color.Gray)
        }
        Spacer(Modifier.height(4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { u ->
                Row(
                    Modifier.fillMaxWidth().clickable(enabled = canEdit) { edit = u }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(u.name, fontWeight = FontWeight.SemiBold)
                        Text("@${u.username}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text(roleLabel(u.role), color = if (u.role == "admin") AppRed else if (u.role == "staff") Olive else Color.DarkGray)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        UserDialog(edit, onClose = { adding = false; edit = null }, onSaved = { tick++ })
    }
}

@Composable
private fun UserDialog(u: User?, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var username by remember { mutableStateOf(u?.username ?: "") }
    var name by remember { mutableStateOf(u?.name ?: "") }
    var pass by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(u?.role ?: "kasir") }
    val isAdmin = (AppState.user?.rank() ?: 0) >= 2

    FullDialog(if (u == null) "Tambah User" else "Ubah User", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("Username / NIK", username, { username = it.replace(" ", "") }, enabled = u == null)
            Field("Nama", name, { name = it })
            Field(if (u == null) "Password" else "Password baru (kosongkan jika tidak diganti)", pass, { pass = it }, password = true)
            if (isAdmin) {
                Picker("Level", roleLabel(role), listOf("kasir" to "Kasir", "staff" to "Staff", "admin" to "Admin")) { role = it }
            } else {
                Text("Level: Kasir", modifier = Modifier.padding(vertical = 8.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            if (u != null && u.id != AppState.user?.id) {
                OutlinedButton(onClick = {
                    val err = db.deleteUser(u.id)
                    if (err != null) toast(ctx, err) else { onSaved(); onClose() }
                }) { Text("Hapus", color = AppRed) }
            }
            Button(
                onClick = {
                    val err = db.saveUser(u?.id ?: 0L, username, name, pass, if (isAdmin) role else "kasir")
                    if (err != null) toast(ctx, err) else { onSaved(); onClose() }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Simpan") }
        }
    }
}

// ------------------------------------------------------------------ Printer

@Composable
private fun PrinterTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    var devices by remember { mutableStateOf(Printer.bonded(ctx)) }
    var mac by remember { mutableStateOf(db.getSetting("printer_mac")) }
    var paper by remember { mutableStateOf(db.getSetting("paper", "32")) }
    var auto by remember { mutableStateOf(db.getSetting("auto_print", "1") == "1") }
    val granted = Printer.hasAll(ctx)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Printer Thermal Bluetooth", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Pasangkan (pairing) printer lebih dulu di Pengaturan Bluetooth Android, lalu pilih di sini.",
            fontSize = 12.sp, color = Color.Gray,
        )
        Spacer(Modifier.height(8.dp))
        if (!granted) {
            Button(onClick = { AppState.askBt() }) { Text("Beri izin Bluetooth") }
            Text("Setelah izin diberikan, ketuk Muat ulang.", fontSize = 12.sp, color = Color.Gray)
        }
        OutlinedButton(onClick = { devices = Printer.bonded(ctx) }) { Text("Muat ulang perangkat") }
        Spacer(Modifier.height(8.dp))

        if (devices.isEmpty()) Text("Belum ada perangkat Bluetooth yang dipasangkan", color = Color.Gray)
        devices.forEach { d ->
            val devName = try { d.name ?: d.address } catch (e: SecurityException) { d.address }
            Row(
                Modifier.fillMaxWidth().clickable {
                    mac = d.address
                    db.setSetting("printer_mac", d.address)
                    db.setSetting("printer_name", devName)
                }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = mac == d.address, onClick = {
                    mac = d.address
                    db.setSetting("printer_mac", d.address)
                    db.setSetting("printer_name", devName)
                })
                Column {
                    Text(devName, fontWeight = FontWeight.SemiBold)
                    Text(d.address, fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
        Divider(Modifier.padding(vertical = 8.dp))

        Text("Ukuran kertas", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = paper == "32", onClick = { paper = "32"; db.setSetting("paper", "32") }, label = { Text("58 mm (32 karakter)") })
            FilterChip(selected = paper == "48", onClick = { paper = "48"; db.setSetting("paper", "48") }, label = { Text("80 mm (48 karakter)") })
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            Text("Cetak struk otomatis setelah bayar", Modifier.weight(1f))
            Switch(checked = auto, onCheckedChange = { auto = it; db.setSetting("auto_print", if (it) "1" else "0") })
        }
        Button(onClick = { printTest(ctx) { toast(ctx, it) } }, enabled = mac.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text("🖨 Tes Cetak")
        }
    }
}

// ------------------------------------------------------------------ Struk

@Composable
private fun StrukTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    val init = remember { RcCfg.load(db) }
    var toko by remember { mutableStateOf(init.toko) }
    var alamat by remember { mutableStateOf(init.alamat) }
    var telp by remember { mutableStateOf(init.telp) }
    var footer by remember { mutableStateOf(init.footer) }
    var ppn by remember { mutableStateOf(init.ppn) }
    var layout by remember { mutableStateOf(init.layout) }
    var feed by remember { mutableStateOf(init.feed.toString()) }
    var tpl by remember { mutableStateOf(TextFieldValue(init.template)) }
    var bonFmt by remember { mutableStateOf(db.getSetting("bon_format", DEFAULT_BON).ifBlank { DEFAULT_BON }) }
    var thousand by remember { mutableStateOf(db.getSetting("thousand_sep", ",")) }
    val width = db.getSetting("paper", "32").toIntOrNull() ?: 32

    fun cfg() = RcCfg(tpl.text, toko, alamat, telp, footer, layout, ppn, (feed.toIntOrNull() ?: 3).coerceIn(0, 10), width)

    fun insert(t: String) {
        val s = tpl.selection
        tpl = TextFieldValue(tpl.text.replaceRange(s.min, s.max, t), TextRange(s.min + t.length))
    }

    val now = System.currentTimeMillis()
    val sample = SaleRow(
        0, db.formatBon(bonFmt.ifBlank { DEFAULT_BON }, now, 1), now,
        AppState.user?.name ?: "KASIR", 58400, 100000, 41600,
    )
    val sampleLines = listOf(
        SaleLine("1001", "DJISAMSOE MF 12", 29200, 1),
        SaleLine("1002", "GG SURYA CKT16", 14600, 2),
    )
    val preview = Receipt.render(cfg(), sample, sampleLines)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Info toko", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Field("Nama toko", toko, { toko = it })
        Field("Alamat (boleh lebih dari satu baris)", alamat, { alamat = it }, minLines = 2)
        Field("Telepon", telp, { telp = it })
        Field("Teks footer (boleh lebih dari satu baris)", footer, { footer = it }, minLines = 2)
        Field("PPN (%) - sudah termasuk di harga, hanya info di struk", ppn, { ppn = it.filter { c -> c.isDigit() || c == '.' }.take(5) }, number = true)

        Spacer(Modifier.height(8.dp))
        Text("Nomor bon", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Field("Format nomor bon", bonFmt, { bonFmt = it })
        Text(
            "Kode: {YYMMDD} {YYYY} {YY} {MM} {DD} {SEQ} (urut 4 digit/hari) {SEQ6}. Contoh hasil: ${sample.receipt}",
            fontSize = 12.sp, color = Color.Gray,
        )

        Spacer(Modifier.height(8.dp))
        Text("Tampilan", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("Baris barang", fontSize = 12.sp, color = Color.Gray)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = layout == "auto", onClick = { layout = "auto" }, label = { Text("Otomatis") })
            FilterChip(selected = layout == "1", onClick = { layout = "1" }, label = { Text("1 baris") })
            FilterChip(selected = layout == "2", onClick = { layout = "2" }, label = { Text("2 baris") })
        }
        Text("Pemisah ribuan (berlaku di seluruh aplikasi)", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = thousand == ",",
                onClick = { thousand = ","; db.setSetting("thousand_sep", ","); AppState.reloadFormat() },
                label = { Text("Koma  37,600") },
            )
            FilterChip(
                selected = thousand == ".",
                onClick = { thousand = "."; db.setSetting("thousand_sep", "."); AppState.reloadFormat() },
                label = { Text("Titik  37.600") },
            )
        }
        Field("Baris kosong di akhir struk (0-10)", feed, { feed = it.filter { c -> c.isDigit() }.take(2) }, number = true)

        Divider(Modifier.padding(vertical = 8.dp))
        Text("Template struk", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Satu baris template = satu baris struk. Awali dengan [L] kiri, [C] tengah. " +
                "Gunakan [R] untuk membagi kiri/kanan, mis. [L]Tunai[R]{TUNAI}. " +
                "Baris yang berisi placeholder kosong otomatis dibuang. Teks biasa boleh diketik langsung (mis. NPWP).",
            fontSize = 12.sp, color = Color.Gray,
        )
        OutlinedTextField(
            value = tpl,
            onValueChange = { tpl = it },
            minLines = 8,
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        )
        Text("Ketuk untuk menyisipkan di posisi kursor:", fontSize = 12.sp, color = Color.Gray)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RECEIPT_TAGS.forEach { (code, desc) ->
                FilterChip(selected = false, onClick = { insert(code) }, label = { Text("$code $desc", fontSize = 12.sp) })
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Pratinjau (kertas $width karakter)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Box(
            Modifier.fillMaxWidth().padding(vertical = 6.dp)
                .background(Color.White)
                .horizontalScroll(rememberScrollState())
                .padding(12.dp),
        ) {
            Text(
                preview.joinToString("\n"),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                lineHeight = 15.sp,
                softWrap = false,
                color = Color.Black,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { tpl = TextFieldValue(DEFAULT_TEMPLATE) },
                modifier = Modifier.weight(1f),
            ) { Text("Template default") }
            OutlinedButton(
                onClick = { sendToPrinter(ctx, Receipt.toBytes(cfg(), preview)) { toast(ctx, it) } },
                modifier = Modifier.weight(1f),
            ) { Text("🖨 Cetak contoh") }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                cfg().save(db)
                db.setSetting("bon_format", bonFmt.trim().ifBlank { DEFAULT_BON })
                AppState.reloadFormat()
                AppState.refreshBon()
                toast(ctx, "Tersimpan")
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Simpan") }
        Spacer(Modifier.height(24.dp))
    }
}

// ------------------------------------------------------------------ Backup

@Composable
private fun BackupTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    val handler = remember { Handler(Looper.getMainLooper()) }
    var busy by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var last by remember { mutableStateOf(db.getSetting("last_backup")) }
    val nItems = remember { db.count("items") }
    val nSales = remember { db.count("sales") }
    val nUsers = remember { db.count("users") }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            busy = true
            val app = ctx.applicationContext
            Thread {
                val msg = try {
                    val text = db.exportJson()
                    val os = app.contentResolver.openOutputStream(uri, "wt") ?: throw Exception("tidak bisa menulis file")
                    os.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    db.setSetting("last_backup", SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()))
                    "Backup berhasil disimpan"
                } catch (e: Exception) {
                    "Backup gagal: ${e.message}"
                }
                handler.post {
                    busy = false
                    last = db.getSetting("last_backup")
                    toast(ctx, msg)
                }
            }.start()
        }
    }

    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Backup & Restore", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Backup menyimpan semua data (barang, menu, user, transaksi, pengaturan struk) ke satu file. " +
                "Simpan file di tempat aman, mis. Google Drive atau penyimpanan HP/flashdisk.",
            fontSize = 12.sp, color = Color.Gray,
        )
        Spacer(Modifier.height(8.dp))
        Text("Saat ini: $nItems barang · $nUsers user · $nSales transaksi")
        Text(
            "Backup terakhir: " + last.ifBlank { "belum pernah" },
            fontSize = 12.sp, color = Color.Gray,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val name = "kasirpos-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"
                saver.launch(name)
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("💾 Backup ke file") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { opener.launch(arrayOf("*/*")) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("♻ Restore dari file") }
        if (busy) Text("Memproses...", modifier = Modifier.padding(top = 8.dp))
        Text(
            "Restore mengganti SEMUA data di HP ini dengan isi file backup. Pengaturan printer HP ini tidak ikut diganti.",
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 12.dp),
        )
    }

    val uri = pendingRestore
    if (uri != null) {
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restore data?") },
            text = { Text("Semua data saat ini (barang, user, transaksi, pengaturan) akan diganti dengan isi file backup. Setelah selesai Anda harus login ulang.") },
            confirmButton = {
                Button(onClick = {
                    pendingRestore = null
                    busy = true
                    val app = ctx.applicationContext
                    Thread {
                        val err = try {
                            val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                                ?: throw Exception("tidak bisa membaca file")
                            db.importJson(bytes.toString(Charsets.UTF_8))
                        } catch (e: Exception) {
                            "Restore gagal: ${e.message}"
                        }
                        handler.post {
                            busy = false
                            if (err == null) {
                                AppState.cart.clear()
                                AppState.pending.clear()
                                AppState.reloadFormat()
                                AppState.user = null
                                toast(ctx, "Restore berhasil. Silakan login kembali.")
                            } else {
                                toast(ctx, err)
                            }
                        }
                    }.start()
                }) { Text("Ya, Restore") }
            },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Batal") } },
        )
    }
}
