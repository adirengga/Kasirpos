package com.kasir.pos

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AdminScreen(onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Barang", "Menu", "User Kasir", "Printer", "Toko")
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(AppRed).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("← Kembali", color = Color.White) }
            Text("Pengaturan Admin", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEachIndexed { i, t ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
            when (tab) {
                0 -> ItemsTab()
                1 -> CategoriesTab()
                2 -> UsersTab()
                3 -> PrinterTab()
                else -> StoreTab()
            }
        }
    }
}

// ------------------------------------------------------------------ Barang

@Composable
private fun ItemsTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf<Item?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick, q) { db.items(q) }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Cari barang / PLU") }, modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { adding = true }) { Text("+ Barang") }
        }
        Text("${list.size} barang · ketuk untuk ubah", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { b ->
                Row(
                    Modifier.fillMaxWidth().clickable { edit = b }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(b.name, fontWeight = FontWeight.SemiBold)
                        Text("${b.plu} · ${b.categoryName}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Rp ${rupiah(b.price)}", fontWeight = FontWeight.Bold)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        ItemDialog(edit, onClose = { adding = false; edit = null }, onSaved = { tick++ })
    }
}

@Composable
private fun ItemDialog(item: Item?, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var plu by remember { mutableStateOf(item?.plu ?: "") }
    var name by remember { mutableStateOf(item?.name ?: "") }
    var price by remember { mutableStateOf(item?.price?.toString() ?: "") }
    var cat by remember { mutableStateOf(item?.categoryId ?: 0L) }
    val cats = remember { db.categories() }
    val catName = cats.firstOrNull { it.id == cat }?.name ?: "Tanpa menu"

    FullDialog(if (item == null) "Tambah Barang" else "Ubah Barang", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("PLU / Barcode", plu, { plu = it })
            Field("Nama barang", name, { name = it })
            Field("Harga (Rp)", price, { price = it.filter { c -> c.isDigit() }.take(12) }, number = true)
            Picker(
                "Menu", catName,
                listOf("0" to "Tanpa menu") + cats.map { it.id.toString() to it.name },
            ) { cat = it.toLong() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            if (item != null) {
                OutlinedButton(onClick = { db.deleteItem(item.id); onSaved(); onClose() }) {
                    Text("Hapus", color = AppRed)
                }
            }
            Button(
                onClick = {
                    val p = price.toLongOrNull()
                    when {
                        plu.isBlank() || name.isBlank() -> toast(ctx, "PLU dan nama wajib diisi")
                        p == null -> toast(ctx, "Harga tidak valid")
                        !db.saveItem(item?.id ?: 0L, plu, name, p, cat) -> toast(ctx, "PLU sudah dipakai barang lain")
                        else -> { onSaved(); onClose() }
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Simpan") }
        }
    }
}

// ------------------------------------------------------------------ Menu (kategori)

@Composable
private fun CategoriesTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<Category?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick) { db.categories() }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { adding = true }) { Text("+ Menu / Kategori") }
        Text("Dipakai untuk mengelompokkan barang di LIST PLU", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { c ->
                Row(Modifier.fillMaxWidth().clickable { edit = c }.padding(vertical = 14.dp)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("Ubah", color = AppRed)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        val c = edit
        var name by remember(c) { mutableStateOf(c?.name ?: "") }
        AlertDialog(
            onDismissRequest = { adding = false; edit = null },
            title = { Text(if (c == null) "Tambah Menu" else "Ubah Menu") },
            text = { Field("Nama menu", name, { name = it }) },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        db.saveCategory(c?.id ?: 0L, name)
                        tick++
                        adding = false; edit = null
                    }
                }) { Text("Simpan") }
            },
            dismissButton = {
                Row {
                    if (c != null) {
                        TextButton(onClick = { db.deleteCategory(c.id); tick++; edit = null }) {
                            Text("Hapus", color = AppRed)
                        }
                    }
                    TextButton(onClick = { adding = false; edit = null }) { Text("Batal") }
                }
            },
        )
    }
}

// ------------------------------------------------------------------ User

@Composable
private fun UsersTab() {
    val db = AppState.db
    var tick by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<User?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = remember(tick) { db.users() }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { adding = true }) { Text("+ User") }
        Spacer(Modifier.height(4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(list) { u ->
                Row(
                    Modifier.fillMaxWidth().clickable { edit = u }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(u.name, fontWeight = FontWeight.SemiBold)
                        Text("@${u.username}", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text(if (u.role == "admin") "Admin" else "Kasir", color = if (u.role == "admin") AppRed else Color.DarkGray)
                }
                Divider()
            }
        }
    }
    if (adding || edit != null) {
        UserDialog(edit, onClose = { adding = false; edit = null }, onSaved = { tick++ })
    }
}

@Composable
private fun UserDialog(u: User?, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val db = AppState.db
    var username by remember { mutableStateOf(u?.username ?: "") }
    var name by remember { mutableStateOf(u?.name ?: "") }
    var pass by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(u?.role ?: "kasir") }

    FullDialog(if (u == null) "Tambah User" else "Ubah User", onClose) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Field("Username", username, { username = it.replace(" ", "") }, enabled = u == null)
            Field("Nama", name, { name = it })
            Field(if (u == null) "Password" else "Password baru (kosongkan jika tidak diganti)", pass, { pass = it }, password = true)
            Picker("Peran", if (role == "admin") "Admin" else "Kasir", listOf("kasir" to "Kasir", "admin" to "Admin")) { role = it }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            if (u != null && u.id != AppState.user?.id) {
                OutlinedButton(onClick = {
                    val err = db.deleteUser(u.id)
                    if (err != null) toast(ctx, err) else { onSaved(); onClose() }
                }) { Text("Hapus", color = AppRed) }
            }
            Button(
                onClick = {
                    val err = db.saveUser(u?.id ?: 0L, username, name, pass, role)
                    if (err != null) toast(ctx, err) else { onSaved(); onClose() }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Simpan") }
        }
    }
}

// ------------------------------------------------------------------ Printer

@Composable
private fun PrinterTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    var devices by remember { mutableStateOf(Printer.bonded(ctx)) }
    var mac by remember { mutableStateOf(db.getSetting("printer_mac")) }
    var paper by remember { mutableStateOf(db.getSetting("paper", "32")) }
    var auto by remember { mutableStateOf(db.getSetting("auto_print", "1") == "1") }
    val granted = Printer.hasPermission(ctx)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Printer Thermal Bluetooth", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Pasangkan (pairing) printer lebih dulu di Pengaturan Bluetooth Android, lalu pilih di sini.",
            fontSize = 12.sp, color = Color.Gray,
        )
        Spacer(Modifier.height(8.dp))
        if (!granted) {
            Button(onClick = { AppState.askBt() }) { Text("Beri izin Bluetooth") }
            Text("Setelah izin diberikan, ketuk Muat ulang.", fontSize = 12.sp, color = Color.Gray)
        }
        OutlinedButton(onClick = { devices = Printer.bonded(ctx) }) { Text("Muat ulang perangkat") }
        Spacer(Modifier.height(8.dp))

        if (devices.isEmpty()) Text("Belum ada perangkat Bluetooth yang dipasangkan", color = Color.Gray)
        devices.forEach { d ->
            val devName = try { d.name ?: d.address } catch (e: SecurityException) { d.address }
            Row(
                Modifier.fillMaxWidth().clickable {
                    mac = d.address
                    db.setSetting("printer_mac", d.address)
                    db.setSetting("printer_name", devName)
                }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = mac == d.address, onClick = {
                    mac = d.address
                    db.setSetting("printer_mac", d.address)
                    db.setSetting("printer_name", devName)
                })
                Column {
                    Text(devName, fontWeight = FontWeight.SemiBold)
                    Text(d.address, fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
        Divider(Modifier.padding(vertical = 8.dp))

        Text("Ukuran kertas", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = paper == "32", onClick = { paper = "32"; db.setSetting("paper", "32") }, label = { Text("58 mm (32 karakter)") })
            FilterChip(selected = paper == "48", onClick = { paper = "48"; db.setSetting("paper", "48") }, label = { Text("80 mm (48 karakter)") })
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            Text("Cetak struk otomatis setelah bayar", Modifier.weight(1f))
            Switch(checked = auto, onCheckedChange = { auto = it; db.setSetting("auto_print", if (it) "1" else "0") })
        }
        Button(onClick = { printTest(ctx) { toast(ctx, it) } }, enabled = mac.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text("🖨 Tes Cetak")
        }
    }
}

// ------------------------------------------------------------------ Toko

@Composable
private fun StoreTab() {
    val ctx = LocalContext.current
    val db = AppState.db
    var name by remember { mutableStateOf(db.getSetting("store_name")) }
    var addr by remember { mutableStateOf(db.getSetting("store_addr")) }
    var phone by remember { mutableStateOf(db.getSetting("store_phone")) }
    var footer by remember { mutableStateOf(db.getSetting("store_footer")) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Informasi di header & footer struk", fontSize = 12.sp, color = Color.Gray)
        Field("Nama toko", name, { name = it })
        Field("Alamat", addr, { addr = it })
        Field("Telepon", phone, { phone = it })
        Field("Teks footer struk", footer, { footer = it })
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                db.setSetting("store_name", name.trim())
                db.setSetting("store_addr", addr.trim())
                db.setSetting("store_phone", phone.trim())
                db.setSetting("store_footer", footer.trim())
                toast(ctx, "Tersimpan")
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Simpan") }
    }
}
