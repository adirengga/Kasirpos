package com.kasir.pos

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object Receipt {
    private fun clean(s: String) = s.map { if (it.code in 32..126) it else '?' }.joinToString("")

    private fun lr(l: String, r: String, w: Int): String {
        val left = if (l.length + r.length + 1 > w) l.take((w - r.length - 1).coerceAtLeast(0)) else l
        return left + " ".repeat((w - left.length - r.length).coerceAtLeast(1)) + r
    }

    fun build(db: Db, s: SaleRow, lines: List<SaleLine>): ByteArray {
        val w = db.getSetting("paper", "32").toIntOrNull() ?: 32
        val out = ByteArrayOutputStream()
        fun raw(vararg b: Int) = out.write(ByteArray(b.size) { b[it].toByte() })
        fun text(t: String) = out.write((clean(t) + "\n").toByteArray(Charsets.US_ASCII))
        fun center(t: String, bold: Boolean = false) {
            if (t.isBlank()) return
            raw(0x1B, 0x61, 1)
            if (bold) raw(0x1B, 0x45, 1)
            t.chunked(w).forEach { text(it) }
            if (bold) raw(0x1B, 0x45, 0)
            raw(0x1B, 0x61, 0)
        }

        val sep = "=".repeat(w)
        val dash = "-".repeat(w)
        raw(0x1B, 0x40)
        center(db.getSetting("store_name"), bold = true)
        center(db.getSetting("store_addr"))
        center(db.getSetting("store_phone"))
        text(sep)
        text("No   : ${s.receipt}")
        text("Kasir: ${s.cashier}")
        text("Tgl  : " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(s.time)))
        text(sep)
        lines.forEach {
            it.name.chunked(w).forEach { part -> text(part) }
            text(lr("  ${it.qty} x ${rupiah(it.price)}", rupiah(it.price * it.qty), w))
        }
        text(dash)
        text(lr("Item", lines.sumOf { it.qty }.toString(), w))
        text(lr("Total Belanja", rupiah(s.total), w))
        text(lr("Tunai", rupiah(s.cash), w))
        text(lr("Kembali", rupiah(s.change), w))
        text(sep)
        center(db.getSetting("store_footer"))
        raw(0x0A, 0x0A, 0x0A, 0x0A)
        return out.toByteArray()
    }
}

object Printer {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun bonded(ctx: Context): List<BluetoothDevice> {
        if (!hasPermission(ctx)) return emptyList()
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter ?: return emptyList()
        return try {
            adapter.bondedDevices.toList().sortedBy { it.name ?: "" }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun write(ctx: Context, mac: String, data: ByteArray): String {
        return try {
            val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return "Perangkat tidak mendukung Bluetooth"
            if (!adapter.isEnabled) return "Bluetooth belum aktif"
            val device = adapter.getRemoteDevice(mac)
            adapter.cancelDiscovery()
            val socket = device.createRfcommSocketToServiceRecord(SPP)
            try {
                socket.connect()
                socket.outputStream.write(data)
                socket.outputStream.flush()
                Thread.sleep(800)
            } finally {
                try { socket.close() } catch (_: Exception) {}
            }
            "Struk dicetak"
        } catch (e: Exception) {
            "Gagal mencetak: ${e.message ?: "printer tidak terhubung"}"
        }
    }
}

/** Kirim data mentah ke printer di thread latar; hasil dikirim ke [done] di thread utama. */
fun sendToPrinter(ctx: Context, data: ByteArray, done: (String) -> Unit) {
    val mac = AppState.db.getSetting("printer_mac")
    if (mac.isBlank()) {
        done("Printer belum dipilih (Admin > Printer)")
        return
    }
    if (!Printer.hasPermission(ctx)) {
        AppState.askBt()
        done("Beri izin Bluetooth, lalu coba lagi")
        return
    }
    val handler = Handler(Looper.getMainLooper())
    val app = ctx.applicationContext
    Thread {
        val msg = Printer.write(app, mac, data)
        handler.post { done(msg) }
    }.start()
}

fun printSale(ctx: Context, saleId: Long, done: (String) -> Unit) {
    val db = AppState.db
    val sale = db.sale(saleId)
    if (sale == null) {
        done("Transaksi tidak ditemukan")
        return
    }
    sendToPrinter(ctx, Receipt.build(db, sale, db.saleLines(saleId)), done)
}

fun printTest(ctx: Context, done: (String) -> Unit) {
    val w = AppState.db.getSetting("paper", "32").toIntOrNull() ?: 32
    val t = "\u001B@\u001Ba\u0001TES CETAK\n" + "=".repeat(w) + "\nPrinter terhubung dengan baik\n\n\n\n"
    sendToPrinter(ctx, t.toByteArray(Charsets.US_ASCII), done)
}
