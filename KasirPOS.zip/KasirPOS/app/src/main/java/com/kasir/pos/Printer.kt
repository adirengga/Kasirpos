package com.kasir.pos

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Placeholder yang bisa dipakai di template struk: (kode, keterangan). */
val RECEIPT_TAGS = listOf(
    "{TOKO}" to "Nama toko",
    "{ALAMAT}" to "Alamat",
    "{TELP}" to "Telepon",
    "{BON}" to "Nomor bon",
    "{KASIR}" to "Nama kasir",
    "{TGL}" to "Tanggal & jam",
    "{ITEMS}" to "Daftar barang",
    "{JML_ITEM}" to "Jumlah item",
    "{TOTAL}" to "Total belanja",
    "{TUNAI}" to "Uang tunai",
    "{KEMBALI}" to "Kembalian",
    "{PPN}" to "Nilai PPN",
    "{PPN_PCT}" to "Persen PPN",
    "{FOOTER}" to "Teks footer",
    "{SEP}" to "Garis ====",
    "{DASH}" to "Garis ----",
    "[L]" to "Rata kiri",
    "[C]" to "Rata tengah",
    "[R]" to "Kolom kanan",
)

/** Pengaturan struk. [template] memakai tag [L]/[C]/[R] dan placeholder {…}. */
data class RcCfg(
    val template: String,
    val toko: String,
    val alamat: String,
    val telp: String,
    val footer: String,
    val layout: String, // "auto", "1" (satu baris), "2" (dua baris)
    val ppn: String,
    val feed: Int,
    val width: Int,
) {
    fun save(db: Db) {
        db.setSetting("rc_template", template)
        db.setSetting("store_name", toko.trim())
        db.setSetting("store_addr", alamat.trim())
        db.setSetting("store_phone", telp.trim())
        db.setSetting("store_footer", footer.trim())
        db.setSetting("rc_layout", layout)
        db.setSetting("rc_ppn", ppn.trim())
        db.setSetting("rc_feed", feed.toString())
    }

    companion object {
        fun load(db: Db) = RcCfg(
            template = db.getSetting("rc_template", DEFAULT_TEMPLATE).ifBlank { DEFAULT_TEMPLATE },
            toko = db.getSetting("store_name"),
            alamat = db.getSetting("store_addr"),
            telp = db.getSetting("store_phone"),
            footer = db.getSetting("store_footer"),
            layout = db.getSetting("rc_layout", "auto"),
            ppn = db.getSetting("rc_ppn", "0"),
            feed = db.getSetting("rc_feed", "3").toIntOrNull() ?: 3,
            width = db.getSetting("paper", "32").toIntOrNull() ?: 32,
        )
    }
}

object Receipt {
    private val TAG = Regex("^\\[([LCR])\\]")

    private fun clean(s: String) = s.map { if (it.code in 32..126 || it == '\n') it else '?' }.joinToString("")

    /** Memotong teks per kata supaya tidak terputus di tengah kata. */
    private fun wrap(t: String, w: Int): List<String> {
        if (t.length <= w) return listOf(t)
        val out = mutableListOf<String>()
        var cur = ""
        for (word in t.split(' ')) {
            if (cur.isEmpty()) cur = word
            else if (cur.length + 1 + word.length <= w) cur += " $word"
            else {
                out.add(cur)
                cur = word
            }
            while (cur.length > w) {
                out.add(cur.take(w))
                cur = cur.drop(w)
            }
        }
        if (cur.isNotEmpty() || out.isEmpty()) out.add(cur)
        return out
    }

    /** Kiri + kanan dalam satu baris; jika tidak muat, dipecah menjadi dua baris. */
    private fun twoCol(l: String, r: String, w: Int): List<String> {
        if (l.length + r.length + 1 <= w) return listOf(l + " ".repeat(w - l.length - r.length) + r)
        return listOf(l, r).filter { it.isNotEmpty() }.flatMap { wrap(it, w) }
    }

    private fun align(t: String, a: Char, w: Int): List<String> {
        if (t.isEmpty()) return listOf("")
        return wrap(t, w).map { p ->
            when (a) {
                'C' -> " ".repeat(((w - p.length) / 2).coerceAtLeast(0)) + p
                'R' -> " ".repeat((w - p.length).coerceAtLeast(0)) + p
                else -> p
            }
        }
    }

    private fun vars(c: RcCfg, s: SaleRow, lines: List<SaleLine>): Map<String, String> {
        val pct = c.ppn.replace(',', '.').toDoubleOrNull() ?: 0.0
        val ppn = if (pct > 0) Math.round(s.total * pct / (100 + pct)) else 0L
        val pctText = if (pct % 1.0 == 0.0) pct.toLong().toString() else pct.toString()
        return mapOf(
            "TOKO" to c.toko,
            "ALAMAT" to c.alamat,
            "TELP" to c.telp,
            "FOOTER" to c.footer,
            "BON" to s.receipt,
            "KASIR" to s.cashier,
            "TGL" to SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date(s.time)),
            "JML_ITEM" to lines.sumOf { it.qty }.toString(),
            "TOTAL" to rupiah(s.total),
            "TUNAI" to rupiah(s.cash),
            "KEMBALI" to rupiah(s.change),
            "PPN" to rupiah(ppn),
            "PPN_PCT" to pctText,
        )
    }

    private fun fill(t: String, v: Map<String, String>): String {
        var r = t
        v.forEach { (k, x) -> r = r.replace("{" + k + "}", clean(x)) }
        return r
    }

    private fun itemLines(c: RcCfg, lines: List<SaleLine>, w: Int): List<String> {
        val single = when (c.layout) {
            "1" -> true
            "2" -> false
            else -> w >= 40
        }
        val out = mutableListOf<String>()
        lines.forEach { l ->
            val name = clean(l.name).replace('\n', ' ')
            val lineTotal = rupiah(l.price * l.qty)
            if (single && w >= 32) {
                val nameW = w - 24
                out.add(
                    name.take(nameW).padEnd(nameW) +
                        l.qty.toString().padStart(3) + " " +
                        rupiah(l.price).padStart(9) + " " +
                        lineTotal.padStart(10),
                )
            } else {
                wrap(name, w).forEach { part -> out.add(part) }
                out.addAll(twoCol("  ${l.qty} x ${rupiah(l.price)}", lineTotal, w))
            }
        }
        return out
    }

    /** Menghasilkan baris-baris struk (sudah rata sesuai lebar kertas). Dipakai untuk cetak dan pratinjau. */
    fun render(c: RcCfg, s: SaleRow, lines: List<SaleLine>): List<String> {
        val w = c.width
        val v = vars(c, s, lines)
        val out = mutableListOf<String>()
        for (raw in c.template.lines()) {
            val line = raw.trimEnd()
            val key = line.trim()
            if (key == "{SEP}") {
                out.add("=".repeat(w))
                continue
            }
            if (key == "{DASH}") {
                out.add("-".repeat(w))
                continue
            }
            if (key == "{ITEMS}") {
                out.addAll(itemLines(c, lines, w))
                continue
            }
            var a = 'L'
            var body = line
            val m = TAG.find(body)
            if (m != null) {
                a = m.groupValues[1][0]
                body = body.substring(m.value.length)
            }
            val hadVar = body.contains('{')
            val idx = body.indexOf("[R]")
            if (idx >= 0) {
                val l = fill(body.substring(0, idx), v).replace('\n', ' ').trimEnd()
                val r = fill(body.substring(idx + 3), v).replace('\n', ' ').trim()
                if (hadVar && l.isBlank() && r.isBlank()) continue
                out.addAll(twoCol(l, r, w))
            } else {
                val t = fill(body, v)
                if (hadVar && t.isBlank()) continue
                t.split('\n').forEach { part ->
                    out.addAll(align(if (a == 'L') part.trimEnd() else part.trim(), a, w))
                }
            }
        }
        return out
    }

    fun toBytes(c: RcCfg, lines: List<String>): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40)) // reset printer
        lines.forEach { out.write((it + "\n").toByteArray(Charsets.US_ASCII)) }
        out.write("\n".repeat(c.feed.coerceIn(0, 10)).toByteArray(Charsets.US_ASCII))
        return out.toByteArray()
    }

    /** Struk hasil tutup shift. */
    fun shiftLines(w: Int, s: ShiftRow, voids: List<VoidEvent>): List<String> {
        fun c1(x: String) = clean(x).replace('\n', ' ')
        val f = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault())
        val sep = "=".repeat(w)
        val out = mutableListOf<String>()
        out.addAll(align("TUTUP SHIFT", 'C', w))
        out.add(sep)
        out.addAll(twoCol("Nama", c1(s.name), w))
        out.addAll(twoCol("User", c1(s.username), w))
        out.addAll(twoCol("Tanggal", f.format(Date(s.endTime)), w))
        out.add(sep)
        out.addAll(twoCol("Disetor (fisik)", rupiah(s.counted), w))
        out.addAll(twoCol("Harus disetor (data)", rupiah(s.expected), w))
        out.addAll(twoCol("Selisih", (if (s.diff > 0) "+" else "") + rupiah(s.diff), w))
        val tag = when {
            s.diff > 0 -> "(LEBIH)"
            s.diff < 0 -> "(KURANG)"
            else -> "(SESUAI)"
        }
        out.addAll(align(tag, 'R', w))
        out.addAll(twoCol("Jumlah transaksi", s.txCount.toString(), w))
        out.add("-".repeat(w))
        out.add("Transaksi batal/dihapus (${voids.size})")
        if (voids.isEmpty()) out.add("  Tidak ada")
        voids.forEach { v ->
            out.addAll(wrap(c1(v.kind) + " " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(v.time)), w))
            out.addAll(twoCol(c1(v.detail), rupiah(v.amount), w))
            if (v.note.isNotBlank()) out.addAll(wrap("  Catatan: " + c1(v.note), w))
            out.addAll(wrap("  Oleh: " + c1(v.by), w))
        }
        out.add(sep)
        out.addAll(wrap("Disetujui: " + c1(s.authBy), w))
        return out
    }

    /** Cetak tabel laporan: tiap baris = judul (kolom pertama) + pasangan "kolom: nilai". */
    fun tableLines(w: Int, t: RTable, printedBy: String): List<String> {
        fun c1(x: String) = clean(x).replace('\n', ' ')
        val sep = "=".repeat(w)
        val out = mutableListOf<String>()
        out.addAll(align(c1(t.title).uppercase(), 'C', w))
        out.add(sep)
        t.info.forEach { out.addAll(wrap(c1(it), w)) }
        out.add(sep)
        fun block(row: List<Any>) {
            out.addAll(wrap(c1(t.cellText(row, 0)), w))
            for (i in 1 until t.headers.size) {
                val v = c1(t.cellText(row, i))
                if (v.isNotEmpty()) out.addAll(twoCol(c1(t.headers[i]), v, w))
            }
        }
        if (t.rows.isEmpty()) out.add("Tidak ada data")
        t.rows.forEach { block(it); out.add("-".repeat(w)) }
        if (t.totals.isNotEmpty()) {
            out.add(sep)
            t.totals.forEach { block(it) }
        }
        out.add(sep)
        out.addAll(wrap("Dicetak: " + SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date()), w))
        out.addAll(wrap("Oleh: " + c1(printedBy), w))
        return out
    }

    fun build(db: Db, s: SaleRow, lines: List<SaleLine>): ByteArray {
        val c = RcCfg.load(db)
        return toBytes(c, render(c, s, lines))
    }
}

object Printer {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    /** Izin minimal untuk mencetak. */
    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    /** Semua izin Bluetooth yang diminta aplikasi. */
    fun hasAll(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || (
            hasPermission(ctx) &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            )

    @SuppressLint("MissingPermission")
    fun bonded(ctx: Context): List<BluetoothDevice> {
        if (!hasPermission(ctx)) return emptyList()
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter ?: return emptyList()
        return try {
            adapter.bondedDevices.toList().sortedBy { it.name ?: "" }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun write(ctx: Context, mac: String, data: ByteArray): String {
        return try {
            val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return "Perangkat tidak mendukung Bluetooth"
            if (!adapter.isEnabled) return "Bluetooth belum aktif"
            val device = adapter.getRemoteDevice(mac)
            // cancelDiscovery butuh izin BLUETOOTH_SCAN di Android 12+; tidak wajib untuk mencetak.
            try { adapter.cancelDiscovery() } catch (_: Throwable) {}

            val makers = listOf<() -> BluetoothSocket>(
                { device.createRfcommSocketToServiceRecord(SPP) },
                { device.createInsecureRfcommSocketToServiceRecord(SPP) },
                {
                    device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        .invoke(device, 1) as BluetoothSocket
                },
            )
            var socket: BluetoothSocket? = null
            var err: Exception? = null
            for (make in makers) {
                var s: BluetoothSocket? = null
                try {
                    s = make()
                    s.connect()
                    socket = s
                    break
                } catch (e: Exception) {
                    err = e
                    try { s?.close() } catch (_: Exception) {}
                }
            }
            val sock = socket ?: return "Gagal terhubung ke printer: ${err?.message ?: "tidak diketahui"}"
            try {
                val os = sock.outputStream
                var i = 0
                while (i < data.size) {
                    val n = minOf(512, data.size - i)
                    os.write(data, i, n)
                    os.flush()
                    i += n
                    Thread.sleep(30)
                }
                Thread.sleep(1000)
            } finally {
                try { sock.close() } catch (_: Exception) {}
            }
            "Struk dicetak"
        } catch (e: Exception) {
            "Gagal mencetak: ${e.message ?: "printer tidak terhubung"}"
        }
    }
}

/** Kirim data mentah ke printer di thread latar; hasil dikirim ke [done] di thread utama. */
fun sendToPrinter(ctx: Context, data: ByteArray, done: (String) -> Unit) {
    val mac = AppState.db.getSetting("printer_mac")
    if (mac.isBlank()) {
        done("Printer belum dipilih (Admin > Printer)")
        return
    }
    if (!Printer.hasPermission(ctx)) {
        AppState.askBt()
        done("Beri izin Bluetooth, lalu coba lagi")
        return
    }
    val handler = Handler(Looper.getMainLooper())
    val app = ctx.applicationContext
    Thread {
        val msg = Printer.write(app, mac, data)
        handler.post { done(msg) }
    }.start()
}

fun printSale(ctx: Context, saleId: Long, done: (String) -> Unit) {
    val db = AppState.db
    val sale = db.sale(saleId)
    if (sale == null) {
        done("Transaksi tidak ditemukan")
        return
    }
    sendToPrinter(ctx, Receipt.build(db, sale, db.saleLines(saleId)), done)
}

fun printShift(ctx: Context, shiftId: Long, done: (String) -> Unit) {
    val db = AppState.db
    val s = db.shifts(0, 100000).firstOrNull { it.id == shiftId }
    if (s == null) {
        done("Data shift tidak ditemukan")
        return
    }
    val c = RcCfg.load(db)
    sendToPrinter(ctx, Receipt.toBytes(c, Receipt.shiftLines(c.width, s, db.shiftEvents(s))), done)
}

fun printTest(ctx: Context, done: (String) -> Unit) {
    val w = AppState.db.getSetting("paper", "32").toIntOrNull() ?: 32
    val t = "TES CETAK\n" + "=".repeat(w) + "\nPrinter terhubung dengan baik\n\n\n\n"
    sendToPrinter(ctx, byteArrayOf(0x1B, 0x40) + t.toByteArray(Charsets.US_ASCII), done)
}

fun printTable(ctx: Context, t: RTable, done: (String) -> Unit) {
    val db = AppState.db
    val c = RcCfg.load(db)
    val by = AppState.user?.let { authLabel(it) } ?: ""
    sendToPrinter(ctx, Receipt.toBytes(c, Receipt.tableLines(c.width, t, by)), done)
}
